﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(FootyQuiz2016.Startup))]
namespace FootyQuiz2016
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
