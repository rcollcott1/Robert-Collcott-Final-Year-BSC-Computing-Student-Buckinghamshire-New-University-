﻿using System.ComponentModel.DataAnnotations;

namespace FootyQuiz2016.Models
{
    public class Question
    {
        [ScaffoldColumn(false)]
        public int QuestionID { get; set; }

        [Required, StringLength(100), Display(Name = "Question")]
        public string QuestionName { get; set; }

        [Required, StringLength(10000), Display(Name = "Choices"), DataType(DataType.MultilineText)]
        public string Choices { get; set; }

        public int? LevelID { get; set; }

        public virtual Level Level { get; set; }
    }
}