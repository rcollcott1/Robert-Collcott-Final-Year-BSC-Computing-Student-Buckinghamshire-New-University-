﻿using System.Data.Entity;
namespace FootyQuiz2016.Models
{
    public class QuestionContext : DbContext
    {
        public QuestionContext() : base("FootyQuiz2016")
        {
        }
        public DbSet<Level> Levels { get; set; }
        public DbSet<Question> Questions { get; set; }
    }
}