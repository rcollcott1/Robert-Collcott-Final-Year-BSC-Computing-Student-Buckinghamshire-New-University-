﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FootyQuiz2016.Models
{
    public class Level
    {
        [ScaffoldColumn(false)]
        public int LevelID { get; set; }

        [Required, StringLength(100), Display(Name = "Name")]
        public string LevelName { get; set; }

        public virtual ICollection<Question> Questions { get; set; }
    }
}