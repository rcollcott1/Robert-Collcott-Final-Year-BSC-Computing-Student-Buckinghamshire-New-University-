﻿using System.Collections.Generic;
using System.Data.Entity;

namespace FootyQuiz2016.Models
{
    public class QuestionDatabaseInitializer : DropCreateDatabaseIfModelChanges<QuestionContext>
    {
        protected override void Seed(QuestionContext context)
        {
            GetLevels().ForEach(l => context.Levels.Add(l));
            GetQuestions().ForEach(q => context.Questions.Add(q));
        }

        private static List<Level> GetLevels()
        {
            var levels = new List<Level> {
                new Level
                {
                    LevelID = 1,
                    LevelName = "Lv1"
                },
                new Level
                {
                    LevelID = 2,
                    LevelName = "Lv2"
                },
                new Level
                {
                    LevelID = 3,
                    LevelName = "Lv3"
                },
            };

            return levels;
        }

        private static List<Question> GetQuestions()
        {
            var questions = new List<Question> {
                new Question
                {
                    QuestionID = 1,
                    QuestionName = "blank",
                    Choices = "blank", 
                    LevelID = 1
               },
                
                new Question
                {
                    QuestionID = 2,
                    QuestionName = "blank..",
                    Choices = "blank", 
                    LevelID = 1
               },

               new Question
                {
                    QuestionID = 3,
                    QuestionName = "blank...",
                    Choices = "blank", 
                    LevelID = 1
               },

            };

            return questions;
        }
    }
}