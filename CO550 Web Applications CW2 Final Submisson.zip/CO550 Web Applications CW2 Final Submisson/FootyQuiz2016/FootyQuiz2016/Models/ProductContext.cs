﻿using System.Data.Entity;
namespace FootyQuiz2016.Models
{
    public class ProductContext : DbContext
    {
        public ProductContext()
            : base("FootyQuiz2016")
        {
        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<CartItem> ShoppingCartItems { get; set; }
    }
}