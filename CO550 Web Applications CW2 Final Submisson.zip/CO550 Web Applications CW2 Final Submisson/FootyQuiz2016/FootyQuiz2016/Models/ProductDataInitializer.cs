﻿using System.Collections.Generic;
using System.Data.Entity;

namespace FootyQuiz2016.Models
{
    public class ProductDatabaseInitializer : DropCreateDatabaseIfModelChanges<ProductContext>
    {
        protected override void Seed(ProductContext context)
        {
            GetCategories().ForEach(c => context.Categories.Add(c));
            GetProducts().ForEach(p => context.Products.Add(p));
        }

        private static List<Category> GetCategories()
        {
            var categories = new List<Category> {
                new Category
                {
                    CategoryID = 1,
                    CategoryName = "Gold"
                },
            };

            return categories;
        }

        private static List<Product> GetProducts()
        {
            var products = new List<Product> {
                new Product
                {
                    ProductID = 1,
                    ProductName = "Gold",
                    Description = "Gold x1", 
                    ImagePath="gold1.jpg",
                    UnitPrice = 0.99,
                    CategoryID = 1
               },
                new Product 
                {
                    ProductID = 2,
                    ProductName = "Golds",
                    Description = "Gold x3",
                    ImagePath="gold3.jpg",
                    UnitPrice = 2.59,
                     CategoryID = 1
               },
            };

            return products;
        }
    }
}