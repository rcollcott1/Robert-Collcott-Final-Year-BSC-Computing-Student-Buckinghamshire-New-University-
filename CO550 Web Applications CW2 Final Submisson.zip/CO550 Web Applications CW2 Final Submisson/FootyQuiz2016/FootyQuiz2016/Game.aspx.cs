﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FootyQuiz2016
{
    public partial class Game : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void SubmitQ1_Click(object sender, EventArgs e)
        {
            string selectedValue = q1.SelectedValue;
            if(selectedValue=="2")
            {
                LabelQ1.ForeColor = System.Drawing.Color.Green;
                LabelQ1.Text="Correct";
            }
            else
            {
                LabelQ1.ForeColor = System.Drawing.Color.Red;
                LabelQ1.Text = "Wrong";
            }
        }

        protected void SubmitQ2_Click(object sender, EventArgs e)
        {
            string selectedValue = q2.SelectedValue;
            if (selectedValue == "2")
            {
                LabelQ2.ForeColor = System.Drawing.Color.Green;
                LabelQ2.Text = "Correct";
            }
            else
            {
                LabelQ2.ForeColor = System.Drawing.Color.Red;
                LabelQ2.Text = "Wrong";
            }
        }

        protected void SubmitQ3_Click(object sender, EventArgs e)
        {
            string selectedValue = q3.SelectedValue;
            if (selectedValue == "2")
            {
                LabelQ3.ForeColor = System.Drawing.Color.Green;
                LabelQ3.Text = "Correct";
            }
            else
            {
                LabelQ3.ForeColor = System.Drawing.Color.Red;
                LabelQ3.Text = "Wrong";
            }
        }
   }
}