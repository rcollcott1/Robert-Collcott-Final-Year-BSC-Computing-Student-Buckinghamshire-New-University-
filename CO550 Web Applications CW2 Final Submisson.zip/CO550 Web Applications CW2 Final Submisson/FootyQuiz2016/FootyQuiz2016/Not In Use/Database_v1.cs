﻿using System.ComponentModel.DataAnnotations;


namespace FootyQuiz2016.Models
{
    public class Databasev1
    {
        public System.Linq.IQueryable<Leaderboard> Rank;

           // Player Enity     
         [Required, StringLength(30), Display(Name = "Name")]
        public int PlayerID { get; set; }

        [Required, StringLength(30), Display(Name = "Player Forename")]
        public string Forename { get; set; }

        [Required, StringLength(30), Display(Name = "Player Surname")]
        public string Surname { get; set; }

        [Required, StringLength(30), Display(Name = "Age")]
        public float Age { get; set; }

         [Required, StringLength(30), Display(Name = "Date Signed Up")]
        public double DateSignedup { get; set; }

         [Required, StringLength(45), Display(Name = "Email")]
        public string EmailAddress { get; set; }

        [Required, StringLength(16), Display(Name = "Password")]
        public string Password { get; set; }


    // Score Enity 
        [Required, StringLength(5), Display(Name = "Level ID")]
        public int LevelID { get; set; }

        [Required, StringLength(30), Display(Name = "Player ID")]
        public int PlayerIDNo { get; set; }

        [Required, StringLength(30), Display(Name = "Score")]
        public int Score { get; set; }


    // Level Enitiy 
        [Required, StringLength(5), Display(Name = "Level ID")]
            public int LevelIDNo { get; set; }

        [Required, StringLength(30), Display(Name = "Player ID")]
        public int PlayerIDRef { get; set; }

        [Required, StringLength(30), Display(Name = "Score")]
             public int Scores { get; set; }

         [Required,StringLength(30), Display(Name ="Earned Gold")]
        public int Gold { get; set; }

    }
 }