﻿using System.Data.Entity;

namespace FootyQuiz2016.Models
{
    public class RankContext: DbContext
  {
    public RankContext() : base("FootyQuiz2016")
    {
    }
    public DbSet<Database> Categories { get; set; }
  }
}