﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6._4_new
{
    class survey
    {
        int hrs[];
        Console.Write(prompt);
        answer = Console.ReadLine;
        int MAX= 24;

        static void Main(string[] args)
        {
            survey mysurvey = new survey();
              mysurvey.enterCount();
              mysurvey.showData();
              mysurvey.showtotal();
              mysurvey.businest();
            
            
            
            int[24] hours:
        
    public int ask int prompt};


    {
    int answer;
    Console.Write(prompt)
    answer 


}


        public void show businest()
{
        int maxValue = hrs.MAX
        Console.Write(maxValue)

}

    }
}
