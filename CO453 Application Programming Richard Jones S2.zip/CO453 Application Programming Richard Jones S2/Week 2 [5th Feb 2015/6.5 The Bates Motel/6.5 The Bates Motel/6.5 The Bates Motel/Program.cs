﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6._5_The_Bates_Motel
{
    class Motel
    {
        public void Main(string[] args)
        {

            int[] rooms;
            const int MAX = 21;

            Motel BatesMotel = new Motel();
            BatesMotel.runMotel();

            public Motel()

            {

                rooms = new int [MAX];      // allows room numbers from 1 to 20


            }


            public void runMotel();
    {
        string choice ="";

        do

        {

        Console.Clear();
        Console.WriteLine("The Bates Motel");
        Console.WriteLine("================");
        

    }





    }




        }
    }

