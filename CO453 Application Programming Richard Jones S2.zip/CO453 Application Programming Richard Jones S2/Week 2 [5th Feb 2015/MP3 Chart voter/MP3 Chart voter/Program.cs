﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP3_Chart_voter
{
    class MP3Chart
    {
        string[] topTen;
        const int MAX = 5;


        public static void Main(string[] args)
        {
            MP3Chart myChart = new MP3Chart();
            myChart.run{};


        public MP3Chart()

        {

            topTen = new string[MAX];

            topTen[0] = "Revolution"; 
            topTen[1] = "Mera Dil Tuta Hain"; 
            topTen[0] = "Revolution"; 
            topTen[0] = "Revolution"; 
            topTen[0] = "Revolution"; 

        }

        }
    }

