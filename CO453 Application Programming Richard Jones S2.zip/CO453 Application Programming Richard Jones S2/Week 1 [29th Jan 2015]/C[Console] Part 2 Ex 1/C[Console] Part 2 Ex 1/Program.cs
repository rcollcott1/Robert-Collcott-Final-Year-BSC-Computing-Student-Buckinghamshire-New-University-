﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Console__Part_2_Ex_1
{
    class Program
    {
        // Robert Collcott
        // ID 21302939



        static void Main(string[] args)
        {
            double weight; 
            double height;
            string input;

            ("Please enter your weight")




        }
    }
}
