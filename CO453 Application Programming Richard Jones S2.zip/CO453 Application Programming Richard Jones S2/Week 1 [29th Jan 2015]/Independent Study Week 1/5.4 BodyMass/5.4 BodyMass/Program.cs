﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5._4_BodyMass
{
    class BMI
    {
        static void Main(string[] args)
        {
            float weight;                                   // Weight has to be a float varaiable as it weight can have decimal points in e.g. 19.24
            string input, name;

            Console.Write("Please enter person name");          // Get user input for the person's name
            name = Console.ReadLine();


                
            Console.Write("Please enter weight");               // Get user input for the person's weight  
            input = Console.ReadLine();
            weight = Convert.ToInt32(input);


            if (weight <= 18.5)
            {


                Console.Write("You are under weight");          // Message will print here to tell the person is under weight


                         
            }


            if (weight <26)
            {

                Console.Write("You are desirable weight for size");  // Message will print here to tell the person is desirable weight


                input = Console.ReadLine();
            }


            if (weight == 30)                                // Message will print here to tell the person is ober weight
            {


                Console.Write("You are overweight");


                input = Console.ReadLine();
            }


            if (weight == 40)           
            {


                Console.Write("You are obse");      // Message will print here to tell the person is obse


                input = Console.ReadLine();
            }


            if (weight >= 41)
            {


                Console.Write("You are severely obse ---- LOOSE SOME WEIGHT"); // Message will print here to tell the person is severely obse


                input = Console.ReadLine();    
            }

                        
        }
    }
}
