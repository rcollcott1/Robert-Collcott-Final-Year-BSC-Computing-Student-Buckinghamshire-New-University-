﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoreMouse
{

    // Robert Collcott 
    // ID 21302939 
    // Computing 
    // 21st March 2015 



    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            MessageBox.Show("The mouse X position is" + e.X);
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)         // 
        {
            ("e.X + e.Y");
        }
    }
}
