using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


//Robert Collcott
//ID:21302939
// Computing 
// Helicopter animation
// 2014-2015 Academic Year 


namespace Animation
{
    public partial class Form1 : Form
    {
        const int MAX = 4;              // number of images in the array 
        Image[] pics = new Image[MAX];  // create array called pics
        Image[] pigs = new Image[MAX];  // create array called pics



        int count = 0;
     
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // load image files into the pics and pigs arrays
            for (int i = 0; i < MAX; i++)
            {
                pics[i] = Image.FromFile("copter" + i + ".gif");
                pigs[i] = Image.FromFile("pig" + i + ".gif");
            }
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            pbxMoving.Image = pics[count];  // show an image from the array
            pbxMoving2.Image = pigs[count];

            count++;                        // move on to next pic
            if (count == MAX) count = 0;    // reset to zero
            
            if(pbxMoving.Left>=this.Width)
            {
                pbxMoving.Left = 0;
            }
            else if(pbxMoving.Top>=this.Height)
            {
                pbxMoving.Top = 0;
            }
            else
            {
                pbxMoving.Left = pbxMoving.Left + 3; // to start motion towards left
                pbxMoving.Top = pbxMoving.Top + 1; // to start motion downwards
            }



            pbxMoving2.Image = pigs[count];  // show an image from the array

            count++;                        // move on to next pic
            if (count == MAX) count = 0;    // reset to zero

            if (pbxMoving.Left >= this.Width)
            {
                pbxMoving2.Left = 0;
            }
            else if (pbxMoving2.Top >= this.Height)
            {
                pbxMoving2.Top = 0;
            }
            else
            {
                pbxMoving2.Left = pbxMoving2.Left + 10; // to start motion towards left
                pbxMoving2.Top = pbxMoving2.Top + 1; // to start motion downwards
            }


           

        }

        private void rbStart_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Interval = 10;
            timer1.Enabled = true;                                               // Start the timer 
        }

        private void rbStop_CheckedChanged(object sender, EventArgs e)          // stop the timer
        {
            timer1.Enabled = false;
        }

        private void btnQuit_Click(object sender, EventArgs e)          // This function exits the program
        {
            Application.Exit();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)       // This function controls the speed of the flight of the helipector and the pig
        {
            int amount = hsbSpeed.Value + 1;        // The amount of speed of the copter and pig
            timer1.Interval = 100/ amount;             // This is the speed of the helicopter 
        }
        
    }
}