using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PoshNosh
{
    public partial class Form1 : Form
    {
        double totalcost = 0;
        double startercost = 0;
        double maincoursecost = 0;
        double dessertcost = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void lstStarter_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (lstStarter.Text)
            {
                case "Soup of the Day"      : startercost = 5.00; break;
                case "Chilli Fish Cakes"    : startercost = 5.50; break;
                case "Caesar Salad"         : startercost = 4.50; break;
                case "King Prawn CousCous"  : startercost = 6.00; break;
                case "Black Pudding Pate"   : startercost = 4.00; break;
                case "Chicken Liver Toast"  : startercost = 3.50; break;
                case "Prawn Cocktail"       : startercost = 5.50; break;
            }
            totalcost = startercost + maincoursecost + dessertcost;
            lblTotal.Text = "�" + totalcost.ToString("0.00");
        }

        private void btQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}