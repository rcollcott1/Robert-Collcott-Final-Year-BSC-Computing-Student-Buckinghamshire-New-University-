﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5._1_Radio_Buttons_Revisted
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            double amount;
            
            
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            amount = Convert.ToDouble(textBox1.Text) * 1.8;
            label1Converted.Text = amount.ToString() + "Dollars";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            amount = Convert.ToDouble(textBox1.Text) * 1.4;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            amount = Convert.ToDouble(textBox1.Text) * 80;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            amount = Convert.ToDouble(textBox1.Text) * 1.4;
        }
    }
}
