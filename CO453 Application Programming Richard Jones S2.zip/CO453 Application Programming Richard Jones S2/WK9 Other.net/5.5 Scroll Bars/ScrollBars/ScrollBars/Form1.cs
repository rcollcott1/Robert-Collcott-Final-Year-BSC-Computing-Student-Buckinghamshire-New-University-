﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScrollBars
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            double degC = vScrollBar1.Value;
            double degF = degC * 9 / 5 + 32;

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label3.Text = degC.ToString("0.00");
            label2.Text = degF.ToString("0.00");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
