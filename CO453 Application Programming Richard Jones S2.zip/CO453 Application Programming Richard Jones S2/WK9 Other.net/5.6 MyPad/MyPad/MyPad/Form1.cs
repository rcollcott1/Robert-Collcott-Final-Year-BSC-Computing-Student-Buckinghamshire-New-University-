﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPad
{
    public partial class Form1 : Form
    {
        double sfd();


        public Form1()
        {
            InitializeComponent();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void formatToolStripMenuItem_Click(object sender, EventArgs e)      // This is the format toolbar of tools
        {

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)           // This is what brings up the Save as dialog box 
        {
            sfd.ShowDialog();
            txtMain.SaveFileDialog();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)           // This is the exit button
        {
            Application.Exit();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)           // This is the open dialog box section 
        {

        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            Font f = new Font(txtMain.Font.Name, 20, FontStyle.Regular);            // This changes the font to Airal and its size to 20 
            
        
        }

        private void Cut_Click(object sender, EventArgs e)
        {

        }
    }
}
