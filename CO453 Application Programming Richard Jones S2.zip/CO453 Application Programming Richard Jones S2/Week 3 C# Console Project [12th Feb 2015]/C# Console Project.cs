using System;

namespace SPSProject

    // Robert Collcott
    // ID 21302939
    // Computing 2014-15 Group A 
    // Week 4 -- The Scissors Paper Stone Game
    // 12th Feburary 2015


{
    class Game                              // Define class game
    
                                            // Delcare variables
    {
        string compChoice;                  // Delcare input choice for computer
        string playerChoice;                // Delcare input choice for player
        int ComputerScore;                  
        int PlayerScore;
        string playername;
        Random randy;

        static void Main()
        {
            Game myGame = new Game();  // create new Game object
            myGame.play();             // call its play method
        }
        //*******************************************************
        public Game()
        {
            randy = new Random();       // create new Random object
        }
        //*******************************************************
        public void play()
        {
            Console.Clear();
            setupScreen();
            introduction();
            getPlayerName();
            getPlayerChoice();
            getComputerChoice();
            drawPlayerChoice();
            printChoices();
            showResult();
            Console.ReadKey();   // wait for a key press
        }
        //********************************************************
        private void setupScreen()
        {
            Console.Title = "The Great Scissors-Paper-Stone Game";
            Console.SetWindowSize(100, 36);
            Console.SetBufferSize(100, 36);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();  // clear screen in chosen colour
        }
        //********************************************************
        private void introduction()
        {
            Console.WriteLine("\t Welcome to the Scissors Paper Stone Game");
            Console.WriteLine("\t==================================");
        }
        //********************************************************

        private void getPlayerName()
        {
            Console.WriteLine("\n\tWhat is your name ?");
            playerChoice = Console.ReadLine();
        }

        private void getPlayerChoice()
        {
            Console.WriteLine("\n\tWhat do you want to choose ?");
            Console.Write("\tScissors Paper or Stone : ");
            playerChoice = Console.ReadLine();
            playerChoice = playerChoice.ToUpper();
        }
        //*******************************************************

        private void PlayerChoice()
        {
            int num;
            num = randy.Next(3);  // pick a random number (0, 1 or 2)
            if (num == 0)
            {
                compChoice = "Stone";

            }
            else
            {
                compChoice = "You lose because stone has blunted against your scissors";
            }
        }


        private void getComputerChoice2()
        {
            int num;
            num = randy.Next(3);  // pick a random number (0, 1 or 2)
            if (num == 0)
            {
                compChoice = "Paper";

            }
            else
            {
                compChoice = "You win because Scissors cut paper";
            }
        }
        
        private void getComputerChoice3()
        {
            int num;
            num = randy.Next(3);  // pick a random number (0, 1 or 2)
            if (num == 0)
            {
                compChoice = "SCISSORS";

            }
            else
            {
                compChoice = "You lose because stone has blunted against your scissors";
            }
        }

        private void getComputerChoice()
        {
            int num;
            num = randy.Next(3);  // pick a random number (0, 1 or 2)
            if (num == 0)
            {
                compChoice = "SCISSORS";

            }
            else
            {
                compChoice = "You lose because stone has blunted against your scissors";
            }
        }

        //***************************************************
        private void printChoices()
        {
            Console.WriteLine("\n\t You picked " + playerChoice);
            Console.WriteLine("\tThe computer choice is " + compChoice);
        }
        //***************************************************
        private void showResult()
        {
            if (playerChoice == compChoice)
            {
                Console.WriteLine("Draw!!");
            }
            else
            {
                Console.WriteLine("Scissors win because scissors cut papers");
                
            }
        }
        //******************************************************
        private void drawPlayerChoice()
        {
            if (playerChoice == "SCISSORS")         
            {
                drawScissors(10, 5);
            }
            else if (playerChoice == "PAPER")
            {
                drawPaper(10, 5);
            }
            else if (playerChoice == "STONE")
            {
                drawStone(10, 5);
            }
        }
        //*******************************************************************
        private void drawScissors(int x, int y)
        {
            Console.SetCursorPosition(x, y++);   // set start position then increment y to move down
            Console.Write("     \\            /");
            Console.SetCursorPosition(x, y++);
            Console.Write("      \\          /");
            Console.SetCursorPosition(x, y++);
            Console.Write("       \\        /");
            Console.SetCursorPosition(x, y++);
            Console.Write("        \\      /");
            Console.SetCursorPosition(x, y++);
            Console.Write("         \\    /");
            Console.SetCursorPosition(x, y++);
            Console.Write("          \\  /");
            Console.SetCursorPosition(x, y++);
            Console.Write("           **");
            Console.SetCursorPosition(x, y++);
            Console.Write("          /  \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("    (----/    \\----)");
            Console.SetCursorPosition(x, y++);
            Console.Write("     \\  /      \\  /");
            Console.SetCursorPosition(x, y++);
            Console.Write("      ==        ==");
            Console.WriteLine("\n\n");
        }
        //**************************************************************
        private void drawStone(int x, int y)
        {
            Console.SetCursorPosition(x, y++);   // set start position then increment y to move down
            Console.Write("                 ___---___     ");
            Console.SetCursorPosition(x, y++);
            Console.Write("              .--         --.    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("           ./   ()       .-. \\.   ");
            Console.SetCursorPosition(x, y++);
            Console.Write("           /   o    .   (   )  \\  ");
            Console.SetCursorPosition(x, y++);
            Console.Write("          / .            '-'    \\  ");
            Console.SetCursorPosition(x, y++);
            Console.Write("         /     ()   ()           \\ ");
            Console.SetCursorPosition(x, y++);
            Console.Write("        |    o           ()       | ");
            Console.SetCursorPosition(x, y++);
            Console.Write("        |      .--.           O   | ");
            Console.SetCursorPosition(x, y++);
            Console.Write("         \\ .  |    |              |  ");
            Console.SetCursorPosition(x, y++);
            Console.Write("          \\   `.__.'     o   .   /    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("           `\\  o    ()         /'    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("              `--___    ___--'    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("                     ---         ");
            Console.WriteLine();
        }
        //************************************************************************
        private void drawPaper(int x, int y)
        {
            Console.SetCursorPosition(x, y++);    // set start position then increment y to move down
            Console.Write("      .--.------------------.");
            Console.SetCursorPosition(x, y++);
            Console.Write("     /      \\  \\ \\ \\ \\ \\ \\ \\ \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("    /   OOO  \\                |");
            Console.SetCursorPosition(x, y++);
            Console.Write("   |   OOOO   || A N D R E X | |");
            Console.SetCursorPosition(x, y++);
            Console.Write("   |   OOOO   |                |");
            Console.SetCursorPosition(x, y++);
            Console.Write("    \\   OOO   /                /");
            Console.SetCursorPosition(x, y++);
            Console.Write("     \\      // / / / / / / / //");
            Console.SetCursorPosition(x, y++);
            Console.Write("       `--'-|| | | | | | | | |");
            Console.SetCursorPosition(x, y++);
            Console.Write("             \\                \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("              \\                \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("               \\                \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("                \\ \\ \\ \\ \\ \\ \\ \\ \\\\");
            Console.SetCursorPosition(x, y++);
            Console.Write("                 \\________________\\");
            Console.WriteLine();
        }
        //************************************************************************
        private void drawSmile()
        {
            Console.WriteLine("\n                    .-\"\"\"\"-.-\"\"\"\"-. ");
            Console.WriteLine("               _.'`               `'._   ");
            Console.WriteLine("            .-'  __..,.___.___.,..__  '-.   ");
            Console.WriteLine("           '-.-;` |  |    |    |  | `;-.-'   ");
            Console.WriteLine("            \\'-\\_/\\__|    |    |__/\\_/-'/   ");
            Console.WriteLine("             \\, _     '---'---'     _ ,/   ");
            Console.WriteLine("              \\'./`'.--.--.--,--.'`\\.'/   ");
            Console.WriteLine("               \\ `'-;__|__|__|__;-'` /   ");
            Console.WriteLine("                '.                 .'   ");
            Console.WriteLine("                 `'-....---....-'`    ");
        }
        //*************************************
        private void drawThumbsUp()
        {
            Console.WriteLine();
            Console.WriteLine("       _ ");
            Console.WriteLine("      ( ((  ");
            Console.WriteLine("       \\ =\\   ");
            Console.WriteLine("      __\\_ `-\\   ");
            Console.WriteLine("     (____))(  \\-----  ");
            Console.WriteLine("     (____)) _    ");
            Console.WriteLine("     (____))   ");
            Console.WriteLine("     (____))____/-----  ");
            Console.WriteLine();
        }
        //*************************************
        private void drawThumbsDown()
        {
            Console.WriteLine();
            Console.WriteLine("       ______ ");
            Console.WriteLine("     ((____  \\-----  ");
            Console.WriteLine("     ((_____         ");
            Console.WriteLine("     ((_____      ");
            Console.WriteLine("     ((____   -----   ");
            Console.WriteLine("          /  /    ");
            Console.WriteLine("         (_((     ");
            Console.WriteLine();
        }

        private void showScores()
        {

        }

    }

    }

        private void showScores()
        {


 class pic();                              // Define class game