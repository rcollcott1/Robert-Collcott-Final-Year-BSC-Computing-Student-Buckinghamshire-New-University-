using System;

namespace SPSProject
{
                    // Robert Collcott
                    // ID 21302939
                    // Computing 
                    // 12th February 2015
    
    
    class Game
    {
        string compChoice;
        string playerName, playerChoice;
        int p, c, r; // To store Player's (p), Computer's (c) scores and Result (r).
        Random randy;

        static void Main()
        {
            Game myGame = new Game();           // create a new Game object
            myGame.play();                       // call its play method
        }
        //*******************************************************

        public Game()                           // Create game class
        {
            randy = new Random();               // define a random object
        }
        //*******************************************************
        public void play()
        {
            setupScreen();
            introduction();
            getPlayerName();						// get user input for the name of the player playing the game 
            Console.Clear();
            while(true)                     // Start a loop        	 // p is for player and c is for computer
            {
                if (p >= 20 || c >= 20) 				// To stop the game when one of the player reaches 20.
                {
                    break;				
                }
                else
                {
                    introduction(); // To keep the intro on screen everytime the game repeats.
                    getPlayerChoice();
                    getComputerChoice();
                    drawPlayerChoice();
                    drawComputerChoice();
                    printChoices();
                    showResult();
                    showScore();
                    Console.ReadKey();   // wait for a key press
                    Console.Clear();	// Clear the screen 
                }
                
            }
            finish();
        }
        //********************************************************
        private void setupScreen()
        {
            Console.Title = " The Great Scissors-Paper-Stone Game";                 // This is the console window title 
            Console.SetWindowSize(150, 60);
            Console.SetBufferSize(150, 60);
            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();  // clear screen in chosen colour
        }
        //********************************************************
        private void introduction()
        {
            Console.WriteLine("\tPlay the Scissors Paper Stone Game");			// Message to welcome the users of the game
            Console.WriteLine("\t==================================");
        }
        //********************************************************
        private void getPlayerName()                                                // This is the get player name function
        {
            Console.Write("\n\tPlease Enter Your Name:   ");
            playerName = Console.ReadLine();
        }
        //*******************************************************
        private void getPlayerChoice()                                              // This is the get player choice function
        {
            Console.WriteLine("\n\tWhat is your choice, " + playerName+" ?");
            Console.Write("\tScissors Paper or Stone : ");
            playerChoice = Console.ReadLine();
            playerChoice = playerChoice.ToUpper();
        }
        //*******************************************************
        private void getComputerChoice()											// Generate the computer choice 
        {
            int num;
            num = randy.Next(3);  // pick a random number (0, 1 or 2)
            if (num == 1)
            {
                compChoice = "SCISSORS";
            }
            else if (num == 2)
            {
                compChoice = "STONE";
            }
            else if (num == 0)
            {
                compChoice = "PAPER";
            }
            else       
            {
                compChoice = "NOT YET DETERMINED";
            }
        }
        //***************************************************
        private void printChoices()
        {
            Console.WriteLine("\n\t"+playerName+" picked " + playerChoice);
            Console.WriteLine("\tThe computer choice is " + compChoice);
        }
        //***************************************************
        private void showResult()												// Shows the result 
        {
            if (playerChoice == compChoice)										// Player choice matches the computers choice 
            {
                Console.WriteLine("\n\tA DRAW!!");								// Display a message saying ITS A DRAW 
                c++;
                p++;
            }
            else if (playerChoice == "PAPER" && compChoice == "STONE")			// if the choice is a players with paper and the computer choice is stone the player wins because paper wraps stone
            {
                 Console.WriteLine("\n\n\t"+playerName+" Won, Because Paper Wraps Stone.");
                 p+=2;
            }
            else if (playerChoice == "PAPER" && compChoice == "SCISSORS")			// if the choice is a players with paper and the computer choice is scissors the computer wins because scissors cut paper
            {
                 Console.WriteLine("\n\n\t Computer Won, Because Scissors Cut Paper.");
                 c+=2;
            }
            else if (playerChoice == "SCISSORS" && compChoice == "PAPER")			// if the choice is a players with paper and the computer choice is scissors the computer wins because scissors cut paper
            {
                Console.WriteLine("\n\n\t" + playerName + " Won, Because Scissors Cut Paper.");
                p+=2;
            }
            else if (playerChoice == "SCISSORS" && compChoice == "STONE")
            {
                Console.WriteLine("\n\n\t Computer Won, Because Stone Blunts Scissors.");
                c+=2;
            }
            else if (playerChoice == "STONE" && compChoice == "PAPER")
            {
                Console.WriteLine("\n\n\t Computer Won, Because Paper Wraps Stone.");
                c+=2;
            }
            else if (playerChoice == "STONE" && compChoice == "SCISSORS")
            {
                Console.WriteLine("\n\n\t" + playerName + " Won, Because Stone Blunts Scissors.");
                p+=2;
            }
          }
        //******************************************************					// This is the draw player choice function this draws the players choices 
        private void drawPlayerChoice()
        {
            if (playerChoice == "SCISSORS")
            {
                drawScissors(10, 5);											// Image position to place the scissors image on the screen
            }
            else if (playerChoice == "PAPER")
            {
                drawPaper(10, 5);												// Image position to place the paper image on the screen
            }
            else if (playerChoice == "STONE")
            {
                drawStone(10, 5);												// Image position to place the paper image on the screen
            }
        }
        //*******************************************************************
        private void drawComputerChoice()
        {
            if (compChoice == "SCISSORS")										// draw the stone image if the computer picked Scissors
            {
                drawScissors(50, 5);
            }
            else if (compChoice == "PAPER")										// draw the stone image if the computer picked Paper
            {
                drawPaper(50, 5);
            }
            else if (compChoice == "STONE")										// draw the stone image if the computer picked stone
            {
                drawStone(50, 5);
            }
        }
         
        //*******************************************************************
        private void showScore()														// show the score display 
        {
            Console.WriteLine("\t**********************************");
            Console.WriteLine("\t"+playerName+" = "+p);
            Console.WriteLine("\tComputer = " + c);
            Console.WriteLine("\t**********************************");

        }
        //*******************************************************************
        private void finish()															// display and finish the game 
        {		
            Console.Clear();															// Clear the screen 
            Console.WriteLine("\t******************");
            Console.WriteLine("\tGame Over !");											// Display a message saying game over and either the computer wins or you as the player wins
            Console.WriteLine("\t******************");
            Console.WriteLine("\tComputer : " + c);
            Console.WriteLine("\t" + playerName + " : " + p);
            if (p > c)
            {
                r = p - c;
                drawThumbsUp();
                Console.WriteLine();
                Console.WriteLine("\t******************");
                Console.WriteLine("\tYOU WIN!!");
                Console.WriteLine("\tBy " + r + " Points");							// This tells the player how points they won by
                Console.WriteLine("\t******************");
            }
            else if (p < c)
            {
                r = c - p;
                drawThumbsDown();
                Console.WriteLine();
                Console.WriteLine("\t******************");
                Console.WriteLine("\tCOMPUTER WINS!!");
                Console.WriteLine("\tBy " + r + " Points");						// This tells the player how points they lost by	
                Console.WriteLine("\t******************");
            }
            else if (p == c)
            {
                drawSmile();
                Console.WriteLine();
                Console.WriteLine("\tGame Drawn! Better Luck Next Time.");		// This tells the player how points they got and the computers points to output a message saying the match has been drawn 
            }
            Console.ReadKey();

        }
        //*******************************************************************
        private void drawScissors(int x, int y)     

                          // draw scissors image
        {
            Console.SetCursorPosition(x, y++);   // set start position then increment y to move down
            Console.Write("     \\            /");
            Console.SetCursorPosition(x, y++);
            Console.Write("      \\          /");
            Console.SetCursorPosition(x, y++);
            Console.Write("       \\        /");			// Write and print out the scissors pieces of the scissors image
            Console.SetCursorPosition(x, y++);
            Console.Write("        \\      /");
            Console.SetCursorPosition(x, y++);
            Console.Write("         \\    /");
            Console.SetCursorPosition(x, y++);
            Console.Write("          \\  /");
            Console.SetCursorPosition(x, y++);
            Console.Write("           **");
            Console.SetCursorPosition(x, y++);
            Console.Write("          /  \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("    (----/    \\----)");
            Console.SetCursorPosition(x, y++);
            Console.Write("     \\  /      \\  /");
            Console.SetCursorPosition(x, y++);
            Console.Write("      ==        ==");
            Console.WriteLine("\n\n");
        }
        //**************************************************************
        private void drawStone(int x, int y)

                // draw stone image
        {
            Console.SetCursorPosition(x, y++);   // set start position then increment y to move down
            Console.Write("                 ___---___     ");
            Console.SetCursorPosition(x, y++);
            Console.Write("              .--         --.    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("           ./   ()       .-. \\.   ");
            Console.SetCursorPosition(x, y++);
            Console.Write("           /   o    .   (   )  \\  ");
            Console.SetCursorPosition(x, y++);
            Console.Write("          / .            '-'    \\  ");
            Console.SetCursorPosition(x, y++);
            Console.Write("         /     ()   ()           \\ ");
            Console.SetCursorPosition(x, y++);
            Console.Write("        |    o           ()       | ");
            Console.SetCursorPosition(x, y++);
            Console.Write("        |      .--.           O   | ");
            Console.SetCursorPosition(x, y++);
            Console.Write("         \\ .  |    |              |  ");
            Console.SetCursorPosition(x, y++);
            Console.Write("          \\   `.__.'     o   .   /    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("           `\\  o    ()         /'    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("              `--___    ___--'    ");
            Console.SetCursorPosition(x, y++);
            Console.Write("                     ---         ");
            Console.WriteLine();
        }
        //************************************************************************
        private void drawPaper(int x, int y)

                    // draw paper image
        {
            Console.SetCursorPosition(x, y++);    // set start position then increment y to move down
            Console.Write("      .--.------------------.");
            Console.SetCursorPosition(x, y++);
            Console.Write("     /      \\  \\ \\ \\ \\ \\ \\ \\ \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("    /   OOO  \\                |");
            Console.SetCursorPosition(x, y++);
            Console.Write("   |   OOOO   || A N D R E X | |");
            Console.SetCursorPosition(x, y++);
            Console.Write("   |   OOOO   |                |");
            Console.SetCursorPosition(x, y++);
            Console.Write("    \\   OOO   /                /");
            Console.SetCursorPosition(x, y++);
            Console.Write("     \\      // / / / / / / / //");
            Console.SetCursorPosition(x, y++);
            Console.Write("       `--'-|| | | | | | | | |");
            Console.SetCursorPosition(x, y++);
            Console.Write("             \\                \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("              \\                \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("               \\                \\");
            Console.SetCursorPosition(x, y++);
            Console.Write("                \\ \\ \\ \\ \\ \\ \\ \\ \\\\");
            Console.SetCursorPosition(x, y++);
            Console.Write("                 \\________________\\");
            Console.WriteLine();
        }
        //************************************************************************
        private void drawSmile()															// draw a smiley if you as the player wins the game  
        {
            Console.WriteLine("\n                    .-\"\"\"\"-.-\"\"\"\"-. ");
            Console.WriteLine("               _.'`               `'._   ");
            Console.WriteLine("            .-'  __..,.___.___.,..__  '-.   ");
            Console.WriteLine("           '-.-;` |  |    |    |  | `;-.-'   ");
            Console.WriteLine("            \\'-\\_/\\__|    |    |__/\\_/-'/   ");
            Console.WriteLine("             \\, _     '---'---'     _ ,/   ");
            Console.WriteLine("              \\'./`'.--.--.--,--.'`\\.'/   ");
            Console.WriteLine("               \\ `'-;__|__|__|__;-'` /   ");
            Console.WriteLine("                '.                 .'   ");
            Console.WriteLine("                 `'-....---....-'`    ");
        }
        //*************************************
        private void drawThumbsUp()															// draw a thumbs up to show you won the game  
        {
            Console.WriteLine();
            Console.WriteLine("         _ ");
            Console.WriteLine("        ( ((  ");
            Console.WriteLine("         \\ =\\   ");
            Console.WriteLine("        __\\_ `-\\   ");
            Console.WriteLine("       (____))(  \\-----  ");
            Console.WriteLine("       (____)) _    ");
            Console.WriteLine("       (____))   ");
            Console.WriteLine("       (____))____/-----  ");
            Console.WriteLine();
        }
        //*************************************
        private void drawThumbsDown()											// draw a thumbs down image if you as the player looses 
        {
            Console.WriteLine();
            Console.WriteLine("         ______ ");
            Console.WriteLine("       ((____  \\-----  ");
            Console.WriteLine("       ((_____         ");
            Console.WriteLine("       ((_____      ");
            Console.WriteLine("       ((____   -----   ");
            Console.WriteLine("            /  /    ");
            Console.WriteLine("           (_((     ");
            Console.WriteLine();
        }
    }
}
