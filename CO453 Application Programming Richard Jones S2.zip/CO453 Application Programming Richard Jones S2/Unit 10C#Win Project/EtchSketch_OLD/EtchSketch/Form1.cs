﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EtchSketch
{
    public partial class Form1 : Form
    {
        // Robert Collcott
        // ID 21302939
        // Computing
        // 14TH May 2015


        public Form1()
        {
            InitializeComponent();



        }











        }

    }



