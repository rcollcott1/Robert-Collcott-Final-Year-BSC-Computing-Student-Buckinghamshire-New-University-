using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace EtchaSketch
{
    // Robert Collcott
    // ID 21302939
    // Computing
    // 28th May 2015
    
    
    
    
    public partial class Form1 : Form
    {
        int x = 50, y = 50, size = 20;                              // This is the vairable that delcares the size 
        int maximum = 100, minimum = 10;
        int red;                                                    // red colour                
        int yellow;                                                 // yellow colour
        int green;                                                  // green colour    
        Random rand = new Random();                                 // random 
        
        Bitmap bm;

        public Form1()
        {
            frmInstructionsSplash_new SScreen = new frmInstructionsSplash_new();            // Get form details of the new splash screen
            SScreen.ShowDialog();                                                           // Shows the splash screen first
            InitializeComponent();      
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
            bm = new Bitmap(this.Width, this.Height);   // create a form-size bitmap
            Graphics g = Graphics.FromImage(bm);        // get a graphic object for the bitmap
            this.BackgroundImage = bm;                  // use the bitmap as the form background

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Brush myBrush = new SolidBrush(Color.FromArgb(red, green, yellow));
            Graphics g = Graphics.FromImage(bm);        // get a graphic object for the bitmap
            g.FillEllipse(Brushes.Yellow, x, y, size, size);                // put a circle in the bitmap and draw it yellow.
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            string input;
            input = keyData.ToString();
            Graphics g = Graphics.FromImage(bm);
            if (input == "Up")                          // get input for an up key press 
            {
                y = y - 5;
                Refresh();
              
            }
            else if (input == "Down")               // get input for a down key press 
            {
                y = y + 5;
                Refresh();
            }
            else if (input == "Left")               // get input for a left key press 
            {
                x = x - 5;
                if (x < 0)
                {
                    x = 1670;

                }

                Refresh();
            }
            else if (input == "Right")             // get input for a right  key press 
            {
                x = x + 5;
                Refresh();
            }
            else if (input == "UP" && input == "Left")
            {
                y = y - 5;
                x = x - 5;
                Refresh();
            }
            else if (input == "UP" && input == "Right")
            {
                y = y - 5;
                x = x + 5;
                Refresh();
            }
            else if (input == "Down" && input == "Left")
            {
                y = y + 5;
                x = x - 5;
                Refresh();
            }
            else if (input == "Down" && input == "Right")
            {
                y = y + 5;
                x = x + 5;
                Refresh();
            }
            else if (input == "C")
            {
                g.Clear(this.BackColor);
                Refresh();
            }
            else if (input == "Escape")
            {
                DialogResult responce;
                responce = MessageBox.Show("Are you sure you want to finish", "Exit", MessageBoxButtons.YesNo);             // get input to exit or stay on in the program
                if(responce == DialogResult.Yes)            // Response by user is user = Yes // Exit the program
                {
                    Application.Exit();
                }
            }
            else if (input == "B")              // Increases the size of the drawing 
            {
                if (size < maximum)
                {
                    size = size + 10;
                }
                Refresh();                      // Referesh the screen after this key press 
            }
            else if (input == "S")
            {
                if (size > minimum)
                {
                    size = size - 10;
                }
                Refresh();                      // Referesh the screen after this key press 
            }
            else if (input == "F1")                 //myBrush.Color = Color.FromArgb(red, green, blue);
            {
                red = rand.Next(0, 255);
                green = rand.Next(0, 255);
                yellow = rand.Next(0, 255);
                g.FillEllipse(Brushes.Blue, x, y, size, size);
                g.FillEllipse(Brushes.Yellow, x, y, size, size);
                                                                            
                Refresh();
                return true;
            }
            return false;    // return true if key processed, otherwise false
        }
 
    }
}//Form2.cs