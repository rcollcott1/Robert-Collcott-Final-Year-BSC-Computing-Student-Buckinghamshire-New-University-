﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

    //Robert Collcott
    //ID:21302939
    // Computing
    // May 2015

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        double n1, n2, answer;                  // These are the varirables 

        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            answer = n1 * n2;                                   //This multipplys the two numbers together
            lblResult.Text = answer.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            n2 = Convert.ToDouble(txtSecondNum.Text);           // convert the second number to double
        }

        private void lblResult_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            answer = n1 + n2;                               //This will add 2 numbers together 
        }

        private void txtFirstNum_TextChanged(object sender, EventArgs e)
        {
            n1 = Convert.ToDouble(txtFirstNum.Text); // convert the first number to double
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            answer = n1 - n2; //This subtracts the two numbers together
            lblResult.Text = answer.ToString();
        }


        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblInfinity_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void btnDiv_Click_1(object sender, EventArgs e)
        {
            if (n1 == 0 | n2 == 0) // If any number is divided by zero this error message will come up
            {
                lblResult.Text = "You cannot divide by \"0\"";
            }
            else // Else continue operating
            {
                answer = n1 / n2;
                lblResult.Text = answer.ToString();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void btnPow_Click(object sender, EventArgs e)
        {
            answer = (n1 + n2) / 2; //Calculate the average
            lblResult.Text = answer.ToString(); //Show the result
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            answer = Math.Pow(n1, n2);                                  //Calculate the first number with the second number 
            lblResult.Text = answer.ToString();                         //Show the result
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblResult.Text = "";

        }

        private void lblR_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            answer = n1 + n2;                                               //This addds the two numbers together
            lblResult.Text = answer.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            answer = n1 * n2;                                            //This multipplys the two numbers together
            lblResult.Text = answer.ToString();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            answer = n1 - n2;                                           //This subtracts the two numbers together
            lblResult.Text = answer.ToString();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (n1 == 0 | n2 == 0)                                      // If any number is divided by zero show the error message
            {
                lblResult.Text = "You canot divide by \"0\"";
            }
            else                                                        // Else continue operating the numbers 
            {
                answer = n1 / n2;
                lblResult.Text = answer.ToString();
            }

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            lblResult.Text = "";
        }
    }
}