﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

                    //  Robert Collcott
                    // ID 21302939
                    // Computing
                    // 28th May 2015

namespace Calculator
{
    public partial class Form1 : Form
    {
        double result = 0.0;
        string input = string.Empty;   //all verables 
        string num1 = string.Empty;
        string num2 = string.Empty;
        char operation;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) //load the form
        {

        }
        //*************************************************************** all calculation 
        private void btn0_Click(object sender, EventArgs e)                 // This is the number 0 on the calculator
        {
            this.lblResult.Text = "";
            input += "0";
            this.lblResult.Text += input;
        }

        private void btnPoint_Click(object sender, EventArgs e)             // This is the point button on the calculator
        {
            this.lblResult.Text = "";
            input += ".";
            this.lblResult.Text += input;
        }

        private void btn1_Click(object sender, EventArgs e)                 // This is the number 1 on the calculator
        {
            this.lblResult.Text = "";
            input += "1";
            this.lblResult.Text += input;
        }

        private void btn2_Click(object sender, EventArgs e)                 // This is the number 2 on the calculator
        {
            this.lblResult.Text = "";
            input += "2";
            this.lblResult.Text += input;
        }

        private void btn3_Click(object sender, EventArgs e)                 // This is the number 3 on the calculator
        {
            this.lblResult.Text = "";
            input += "3";
            this.lblResult.Text += input;
        }

        private void btn4_Click(object sender, EventArgs e)                 // This is the number 4 on the calculator
        {
            this.lblResult.Text = "";
            input += "4";
            this.lblResult.Text += input;
        }

        private void btn5_Click(object sender, EventArgs e)             // This is the number 5 on the calculator
        {
            this.lblResult.Text = "";
            input += "5";
            this.lblResult.Text += input;
        }

        private void btn6_Click(object sender, EventArgs e)            // This is the number 6 on the calculator
        
        {
            this.lblResult.Text = "";
            input += "6";
            this.lblResult.Text += input;
        }

        private void btn7_Click(object sender, EventArgs e)             // This is the number 7 on the calculator
        
        {
            this.lblResult.Text = "";
            input += "7";
            this.lblResult.Text += input;
        }

        private void btn8_Click(object sender, EventArgs e)          // This is the number 8 on the calculator
        
        {
            this.lblResult.Text = "";
            input += "8";
            this.lblResult.Text += input;
        }

        private void pictureBox4_Click(object sender, EventArgs e)                          // This is the number 9 on the calculator
        
        {
            this.lblResult.Text = "";
            input += "9";
            this.lblResult.Text += input;
        }

        private void btnAdd_Click(object sender, EventArgs e)               // the add button code addition 
        {
            num1 = input;
            operation = '+';
            input = string.Empty;
            this.lblResult.Text = "";
        }

        private void btnMinus_Click(object sender, EventArgs e)             // this button performs subtraction sums
        
        {
            num1 = input;
            operation = '-';
            input = string.Empty;
            this.lblResult.Text = "";
        }

        private void btnMulti_Click(object sender, EventArgs e)             // this button performs mutiplaction sums 
        {
            num1 = input;
            operation = '*';
            input = string.Empty;
            this.lblResult.Text = "";
        }

        private void btnDiv_Click(object sender, EventArgs e)              // this button divides sums 
        {
            num1 = input;
            operation = '/';
            input = string.Empty;
            this.lblResult.Text = "";
        }

        private void btnClear_Click(object sender, EventArgs e)        // this button clears the calculator
        {
            this.lblResult.Text = "";
            this.input = string.Empty;
            this.num1 = string.Empty;
            this.num2 = string.Empty;
        }

        private void btnResult_Click(object sender, EventArgs e)        // calculates the result
        {
            num2 = input;
            double n1, n2;
            double.TryParse(num1, out n1);
            double.TryParse(num2, out n2);
            this.lblResult.Text = "";
            this.input = string.Empty;
            this.num1 = string.Empty;
            this.num2 = string.Empty;

            if (operation == '+')
            {
                result = n1 + n2;
                lblResult.Text = result.ToString();
            }

            else if (operation == '-')
            {
                result = n1 - n2;
                lblResult.Text = result.ToString();
            }

            else if (operation == '*')
            {
                result = n1 * n2;
                lblResult.Text = result.ToString();
            }

            else if (operation == '/')
            {
                if (n2 != 0)
                {
                    result = n1 / n2;
                    lblResult.Text = result.ToString();
                }
            }
        }

        private void lblResult_Click(object sender, EventArgs e)
        {

        }
    }
}

