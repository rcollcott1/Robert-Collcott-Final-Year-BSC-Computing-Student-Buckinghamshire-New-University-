﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_SPS_Game
{
    public partial class Form1 : Form
    {
       
       // Robert Collcott
       // ID 21302939
       // Computing
        // 5th March 2015
        // Week 3 C# Windows .NET 
        
        
        
        public Form1()                      // Declare Variables 
        {
            InitializeComponent();
            double compChoice;
            double userChoice;
            Random r = new Random();
            compChoice = r.Next(3) + 1;
            Image;
        }

       // Here is the code 



        private void rbn_CheckedChanged(object sender, EventArgs e)
        {
           pbxUser.Image = Image.FromFile("Scissors.jpg");              
        }

                 // Hit the Scissors radio button to select Scissors 
               

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            pbxUser.Image = Image.FromFile("Paper.jpg");
          
        }

                // Hit the Paper radio button to select Paper 

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            pbxUser.Image = Image.FromFile("Stone.jpg");
        }

             // Hit the Stone button to select Stone 

        private void button1_Click(object sender, EventArgs e)
        {

            Application.Exit();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (compChoice == 3);

           Image.FromFile("Scissors.jpg");

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (choice == 1);

          Image.FromFile("Paper.jpg");


        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (compChoice == 2);

         Image.FromFile("Stone.jpg");
        }
    }
}
