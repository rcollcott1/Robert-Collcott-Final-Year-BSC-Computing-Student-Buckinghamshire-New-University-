﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Robert Collcott
// ID 21302939
// Computing 
// Super Surfer exercise 1.5 
// Unit 1 and Week 1 of C# Windows Programming 
// 19th Febaury 2015


namespace _1._5_Super_Surfer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)      // Picture of the super surfer
        {
            
        }

        private void button4_Click(object sender, EventArgs e)  // Change colour of form to blue
        {
            this.BackColor = Color.Blue;

        }

        private void button3_Click(object sender, EventArgs e)      // quit the program
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)      // Change colour of form to red
        {
            this.BackColor = Color.Red;

        }

        private void button6_Click(object sender, EventArgs e)      // Change colour of form to yellow
        {
            this.BackColor = Color.Yellow;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
