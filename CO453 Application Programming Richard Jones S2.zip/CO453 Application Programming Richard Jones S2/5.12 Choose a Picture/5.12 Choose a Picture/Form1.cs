﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5._12_Choose_a_Picture
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            pbxChoice.Image = Image.FromFile("alien.gif");
            pbxChoice.Image = Image.FromFile("Dragon.gif");
            pbxChoice.Image = Image.FromFile("Godzilla.jpg");
            pbxChoice.Image = Image.FromFile("Hydra.gif");
            pbxChoice.Image = Image.FromFile("kong.gif");
            pbxChoice.Image = Image.FromFile("medusa.jpg");
            pbxChoice.Image = Image.FromFile("munsters.jpg");
            pbxChoice.Image = Image.FromFile("Nessie.jpg");
            pbxChoice.Image = Image.FromFile("piratespider.gif");
            pbxChoice.Image = Image.FromFile("RedHarpy.gif");
            pbxChoice.Image = Image.FromFile("scorpius.jpg");
            pbxChoice.Image = Image.FromFile("Shadow.jpg");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            
  
           
        }

        private void Score_Click(object sender, EventArgs e)
        {
            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
