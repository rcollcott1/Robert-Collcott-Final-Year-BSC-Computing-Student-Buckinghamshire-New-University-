﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

        //  Robert Collcott
        //  ID:21302939
        //  Computing 
        //  2014-2015 Academic Year
        

namespace SPS_Game
{
    public partial class Form1 : Form
    {
        int compChoice, userChoice;                 // 2 variables here 1 for user player choice and the other one for computer choice
        int userScore = 0, compScore = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnQuit_Click(object sender, EventArgs e)              // This exits the program 
        {
            Application.Exit();
        }

        private void rbnScissors_CheckedChanged(object sender, EventArgs e)
        {
            pbxUser.Image = Image.FromFile("Scissors.jpg");                     // Get a scissors image from a file and display it
            userChoice = 1;
        }

        private void rbnPapper_CheckedChanged(object sender, EventArgs e)       // Get a Paper image from a file and display it
        {
            pbxUser.Image = Image.FromFile("Paper.jpg");
            userChoice = 2;
        }

        private void rbnStone_CheckedChanged(object sender, EventArgs e)        // Get a Stone image from a file and display it
        {
            pbxUser.Image = Image.FromFile("Stone.jpg");
            userChoice = 3;
        }

        private void btnPlay_Click(object sender, EventArgs e)                  // This is the button that starts the game off 
        {
            Random r = new Random();                                            // Generate a random choice for the computer player
            compChoice = r.Next(3) + 1;

            if (compChoice == 1)
            {
                pbxComputer.Image = Image.FromFile("Scissors.jpg");             // Display the scissors image if computer choice is 1
            }
            else if (compChoice == 2)
            {
                pbxComputer.Image = Image.FromFile("Paper.jpg");            // Display the paper image if computer choice is 2
            }
            else if (compChoice == 3)
            {
                pbxComputer.Image = Image.FromFile("Stone.jpg");        // Display the stone image if computer choice is 3
            }
            chkResult();
            lblCompScore.Text = compScore.ToString();
            lblUserScore.Text = userScore.ToString();

          
            if (userScore >= 20)                                        // If the user score gets up to 20 display an image on a screen saying the player has won
            {
                new YouWin().Show();
                this.Hide();
                System.Threading.Thread.Sleep(2000);
                this.Close();
            }
            else if (compScore >= 20)                                   // If the computer score gets up to 20 display an image on a screen saying the computer has won
            {
                new CompWin().Show();
                this.Hide();
                System.Threading.Thread.Sleep(2000);
                this.Close();
            }
            else if (userScore >= 20 & compScore >= 20)         // if player and computer score match call the game and display a message saying ITS A DRAW.
            {
                new Draw().Show();
                this.Hide();
                System.Threading.Thread.Sleep(2000);
                this.Close();
            }
            //**********************************************************************************************
        }

        private void pbxComputer_Click(object sender, EventArgs e)          
        {
          
        }                                                   // check result function 
        private void chkResult() 
        {
            if (userChoice == compChoice)                            // Call it a draw if the player choice and the computer choice
            {                                                           // match    
                lblResult.Text = "DRAW!";
                this.BackColor = Color.White;                   
                this.ForeColor = Color.Black;
                userScore++;                                        // Increment the player score up by 1 each time 
                compScore++;                                        // Increment the computer score up by 1 each time
            }
            else if (userChoice == 2 & compChoice == 3)             // if player choice is 2 and computer choice is 3
            {                                                       // the player wins because paper blunts paper
                lblResult.Text = "You Win!!";
                this.BackColor = Color.LightBlue;
                this.ForeColor = Color.Orange;
                userScore = userScore + 2;
            }
            else if (userChoice == 2 & compChoice == 1)                // if player choice is 2 and computer choice is 1
            {                                                          // the computer wins because scissors cut paper
                lblResult.Text = "The Computer Wins this time!!";
                this.BackColor = Color.White;
                this.ForeColor = Color.Black;
                compScore = compScore + 2;
            }
            else if (userChoice == 1 && compChoice == 2) 
            {
                lblResult.Text = "You Win!!";
                this.BackColor = Color.LightBlue;
                this.ForeColor = Color.Orange;
                userScore = userScore + 2;
            }
            else if (userChoice == 1 && compChoice == 3)
            {
                lblResult.Text = "Computer Wins!!";
                this.BackColor = Color.White;
                this.ForeColor = Color.Black;
                compScore = compScore + 2;
            }
            else if (userChoice == 3 && compChoice == 2) 
            {
                lblResult.Text = "Computer Wins!!";
                this.BackColor = Color.White;
                this.ForeColor = Color.Black;
                compScore = compScore + 2;
            }
            else if (userChoice == 3 && compChoice == 1) 
            {
                lblResult.Text = "You Win!!";
                this.BackColor = Color.LightBlue;
                this.ForeColor = Color.Orange;
                userScore = userScore + 2;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            frmSplash Sscreen = new frmSplash();                        // Load up the splash screen
            Sscreen.Show();
            System.Threading.Thread.Sleep(10000);
            Sscreen.Close();
            this.BackColor = Color.Black;                               // Black is the background colour
            this.ForeColor = Color.White;                               // White is foreground colour    
            pbxComputer.Image=Image.FromFile("sps3.jpg");
            pbxUser.Image=Image.FromFile("sps1.jpg");
        }
    }
}
