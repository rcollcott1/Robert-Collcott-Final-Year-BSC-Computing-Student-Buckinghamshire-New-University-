﻿namespace SPS_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pbxUser = new System.Windows.Forms.PictureBox();
            this.rbnScissors = new System.Windows.Forms.RadioButton();
            this.rbnPapper = new System.Windows.Forms.RadioButton();
            this.rbnStone = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pbxComputer = new System.Windows.Forms.PictureBox();
            this.btnPlay = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUserScore = new System.Windows.Forms.Label();
            this.lblCompScore = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUser)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxComputer)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pbxUser);
            this.groupBox1.Controls.Add(this.rbnScissors);
            this.groupBox1.Controls.Add(this.rbnPapper);
            this.groupBox1.Controls.Add(this.rbnStone);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(213, 241);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User Choice";
            // 
            // pbxUser
            // 
            this.pbxUser.Location = new System.Drawing.Point(3, 22);
            this.pbxUser.Name = "pbxUser";
            this.pbxUser.Size = new System.Drawing.Size(204, 129);
            this.pbxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxUser.TabIndex = 6;
            this.pbxUser.TabStop = false;
            // 
            // rbnScissors
            // 
            this.rbnScissors.AutoSize = true;
            this.rbnScissors.Location = new System.Drawing.Point(36, 154);
            this.rbnScissors.Name = "rbnScissors";
            this.rbnScissors.Size = new System.Drawing.Size(87, 24);
            this.rbnScissors.TabIndex = 3;
            this.rbnScissors.TabStop = true;
            this.rbnScissors.Text = "Scissors";
            this.rbnScissors.UseVisualStyleBackColor = true;
            this.rbnScissors.CheckedChanged += new System.EventHandler(this.rbnScissors_CheckedChanged);
            // 
            // rbnPapper
            // 
            this.rbnPapper.AutoSize = true;
            this.rbnPapper.Location = new System.Drawing.Point(36, 177);
            this.rbnPapper.Name = "rbnPapper";
            this.rbnPapper.Size = new System.Drawing.Size(78, 24);
            this.rbnPapper.TabIndex = 4;
            this.rbnPapper.TabStop = true;
            this.rbnPapper.Text = "Papper";
            this.rbnPapper.UseVisualStyleBackColor = true;
            this.rbnPapper.CheckedChanged += new System.EventHandler(this.rbnPapper_CheckedChanged);
            // 
            // rbnStone
            // 
            this.rbnStone.AutoSize = true;
            this.rbnStone.Location = new System.Drawing.Point(36, 200);
            this.rbnStone.Name = "rbnStone";
            this.rbnStone.Size = new System.Drawing.Size(70, 24);
            this.rbnStone.TabIndex = 5;
            this.rbnStone.TabStop = true;
            this.rbnStone.Text = "Stone";
            this.rbnStone.UseVisualStyleBackColor = true;
            this.rbnStone.CheckedChanged += new System.EventHandler(this.rbnStone_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pbxComputer);
            this.groupBox2.Controls.Add(this.btnPlay);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(219, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(210, 241);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Computer Choice";
            // 
            // pbxComputer
            // 
            this.pbxComputer.Location = new System.Drawing.Point(6, 22);
            this.pbxComputer.Name = "pbxComputer";
            this.pbxComputer.Size = new System.Drawing.Size(198, 129);
            this.pbxComputer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxComputer.TabIndex = 7;
            this.pbxComputer.TabStop = false;
            this.pbxComputer.Click += new System.EventHandler(this.pbxComputer_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.Location = new System.Drawing.Point(63, 207);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 23);
            this.btnPlay.TabIndex = 3;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblCompScore);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.lblUserScore);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.lblResult);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(435, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 212);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Result";
            // 
            // lblResult
            // 
            this.lblResult.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(7, 32);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(188, 45);
            this.lblResult.TabIndex = 3;
            this.lblResult.Text = "Choose and click play";
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(560, 225);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 2;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "User Score";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Computer Score";
            // 
            // lblUserScore
            // 
            this.lblUserScore.AutoSize = true;
            this.lblUserScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserScore.Location = new System.Drawing.Point(95, 109);
            this.lblUserScore.Name = "lblUserScore";
            this.lblUserScore.Size = new System.Drawing.Size(19, 20);
            this.lblUserScore.TabIndex = 3;
            this.lblUserScore.Text = "0";
            this.lblUserScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCompScore
            // 
            this.lblCompScore.AutoSize = true;
            this.lblCompScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompScore.Location = new System.Drawing.Point(95, 164);
            this.lblCompScore.Name = "lblCompScore";
            this.lblCompScore.Size = new System.Drawing.Size(19, 20);
            this.lblCompScore.TabIndex = 4;
            this.lblCompScore.Text = "0";
            this.lblCompScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 260);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUser)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxComputer)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.RadioButton rbnScissors;
        private System.Windows.Forms.RadioButton rbnPapper;
        private System.Windows.Forms.RadioButton rbnStone;
        private System.Windows.Forms.PictureBox pbxUser;
        private System.Windows.Forms.PictureBox pbxComputer;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblCompScore;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblUserScore;
        private System.Windows.Forms.Label label1;
    }
}

