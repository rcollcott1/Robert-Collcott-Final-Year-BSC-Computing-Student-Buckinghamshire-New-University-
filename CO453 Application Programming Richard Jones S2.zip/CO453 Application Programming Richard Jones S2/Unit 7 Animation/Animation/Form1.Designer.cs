namespace Animation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnQuit = new System.Windows.Forms.Button();
            this.pbxMoving = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.rbStop = new System.Windows.Forms.RadioButton();
            this.rbStart = new System.Windows.Forms.RadioButton();
            this.pbxMoving2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMoving)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMoving2)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnQuit
            // 
            this.btnQuit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuit.Location = new System.Drawing.Point(463, 316);
            this.btnQuit.Margin = new System.Windows.Forms.Padding(2);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(66, 35);
            this.btnQuit.TabIndex = 0;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // pbxMoving
            // 
            this.pbxMoving.BackColor = System.Drawing.Color.Transparent;
            this.pbxMoving.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pbxMoving.Image = ((System.Drawing.Image)(resources.GetObject("pbxMoving.Image")));
            this.pbxMoving.Location = new System.Drawing.Point(96, 10);
            this.pbxMoving.Margin = new System.Windows.Forms.Padding(2);
            this.pbxMoving.Name = "pbxMoving";
            this.pbxMoving.Size = new System.Drawing.Size(139, 110);
            this.pbxMoving.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxMoving.TabIndex = 4;
            this.pbxMoving.TabStop = false;
            this.pbxMoving.Click += new System.EventHandler(this.pbxMoving_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.hScrollBar1);
            this.panel2.Controls.Add(this.rbStop);
            this.panel2.Controls.Add(this.rbStart);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.ForeColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(11, 307);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(331, 44);
            this.panel2.TabIndex = 7;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.Location = new System.Drawing.Point(179, 14);
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(122, 17);
            this.hScrollBar1.TabIndex = 8;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // rbStop
            // 
            this.rbStop.AutoSize = true;
            this.rbStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbStop.Location = new System.Drawing.Point(105, 7);
            this.rbStop.Margin = new System.Windows.Forms.Padding(2);
            this.rbStop.Name = "rbStop";
            this.rbStop.Size = new System.Drawing.Size(61, 24);
            this.rbStop.TabIndex = 2;
            this.rbStop.TabStop = true;
            this.rbStop.Text = "Stop";
            this.rbStop.UseVisualStyleBackColor = true;
            this.rbStop.CheckedChanged += new System.EventHandler(this.rbStop_CheckedChanged);
            // 
            // rbStart
            // 
            this.rbStart.AutoSize = true;
            this.rbStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbStart.Location = new System.Drawing.Point(8, 7);
            this.rbStart.Margin = new System.Windows.Forms.Padding(2);
            this.rbStart.Name = "rbStart";
            this.rbStart.Size = new System.Drawing.Size(62, 24);
            this.rbStart.TabIndex = 1;
            this.rbStart.TabStop = true;
            this.rbStart.Text = "Start";
            this.rbStart.UseVisualStyleBackColor = true;
            this.rbStart.CheckedChanged += new System.EventHandler(this.rbStart_CheckedChanged);
            // 
            // pbxMoving2
            // 
            this.pbxMoving2.Image = ((System.Drawing.Image)(resources.GetObject("pbxMoving2.Image")));
            this.pbxMoving2.Location = new System.Drawing.Point(418, 22);
            this.pbxMoving2.Name = "pbxMoving2";
            this.pbxMoving2.Size = new System.Drawing.Size(111, 73);
            this.pbxMoving2.TabIndex = 8;
            this.pbxMoving2.TabStop = false;
            this.pbxMoving2.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Animation.Properties.Resources.City1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(615, 375);
            this.ControlBox = false;
            this.Controls.Add(this.pbxMoving2);
            this.Controls.Add(this.pbxMoving);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnQuit);
            this.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Come Fly with Me";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxMoving)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMoving2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.PictureBox pbxMoving;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rbStop;
        private System.Windows.Forms.RadioButton rbStart;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.PictureBox pbxMoving2;
    }
}

