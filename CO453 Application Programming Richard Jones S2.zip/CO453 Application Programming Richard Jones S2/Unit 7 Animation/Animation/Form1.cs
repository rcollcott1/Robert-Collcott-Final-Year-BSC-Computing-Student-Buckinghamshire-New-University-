using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Animation
{
    public partial class Form1 : Form
    {
        const int MAX = 4;              // number of images
        Image[] pics = new Image[MAX];  // create array called pics
        Image[] img = new Image[MAX];  // create array called pics
        int count = 0;
     
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // load image files into the pics array
            for (int i = 0; i < MAX; i++)
            {
                pics[i] = Image.FromFile("copter" + i + ".gif");
                img[i] = Image.FromFile("Pig" + i + ".gif");
            }
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            pbxMoving.Image = pics[count];  // show an image from the array
            pbxMoving2.Image = img[count];  // show an image from the array
            count++;                        // move on to next pic
            if (count == MAX) count = 0;    // reset to zero
            Bitmap bm = new Bitmap("City2.wmf");
            this.BackgroundImage = bm;
        }

        private void rbStart_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void rbStop_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pbxMoving_Click(object sender, EventArgs e)
        {
            if(pbxMoving.Left>this.Width)
            {

                pbxMoving.Left = 0;


            }
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            int amount = hScrollBar1.Value + 1;
            timer1.Interval = 1000 / amount;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            {
                if (pbxMoving.Left > this.Width)
                {

                    pbxMoving.Left = 0;


                }
            }
        }
        
    }
}