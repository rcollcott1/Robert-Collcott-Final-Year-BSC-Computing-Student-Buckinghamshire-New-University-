using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Graphics3
{
    // author Robert Collcott
    // ID 21302939
    // Computing
    // Date 7th April 2015
    // Drawing graphics on a form

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;             	// get a graphics object
            Pen myPen = new Pen(Color.Red, 10);  	// create a new red pen
            

            Point[] shape = new Point[6];        	// create an array of points
            shape[0] = new Point(200, 100);         // put 6 points into the array
            shape[1] = new Point(300, 200);
            shape[2] = new Point(100, 200);
            shape[3] = new Point(200, 300);
            shape[4] = new Point(200, 300);
            shape[5] = new Point(200, 300);


            g.DrawPolygon(myPen, shape);             // draw shape using red`pen
            g.FillHexagon(Brushes.Red, shape);   // fill shape using a yellow brush 


            draw.String("Robert Collcott's hexagon");

        }


    }
}