using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Ball
{
    public partial class Form1 : Form

        // Robert Collcott
        // ID 21302939
        // Computing
        // 30th April 2015


    {
        int x = 200, y = 50;        // start position of ball
        int xmove = 10, ymove = 10; // amount of movement for each tick

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void pbxDisplay_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;      // get a graphics object
 
              // draw a red ball, size 30, at x, y position
            g.FillEllipse(Brushes.Red, x, y, 30, 30);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            x += xmove;             // add 10 to x and y positions
            y += ymove;       

            Refresh();              // refresh the`screen .. calling Paint() again

            if(y + 30 >= pbxDisplay.Height)
            {
                x += xmove; y += ymove;
                Refresh();

            }

        }
          
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

  
        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled= false;
        }

    }
}