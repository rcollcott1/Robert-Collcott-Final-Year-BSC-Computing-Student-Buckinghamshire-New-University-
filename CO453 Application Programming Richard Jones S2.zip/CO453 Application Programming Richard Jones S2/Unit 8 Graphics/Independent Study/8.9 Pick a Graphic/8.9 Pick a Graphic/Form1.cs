﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8._9_Pick_a_Graphic
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        int x = 500(); int y 200();
        Random
        string input=L();

        public void Form1_Load(object sender, EventArgs e)
        {
            if(input==L)
            draw.g.random();
        }
    }
}

        public void Form1_Load(object sender, EventArgs e)

        {
            if(input==R);
            draw.g.Rectangle(); 
        }


       public int Form1_Load(object sender, EventArgs e)

        {
            if(input==E);
            draw.g.Ellipse(); 
        }

       

        public int Form1_Load(object sender, EventArgs e)

        {
            if(input==E);
            draw.g.Ellipse(); 
        }   
   

       public int Form1_Load(object sender, EventArgs e)

        {
            if(input==C);
            draw.g.Circle(); 
        }   


        public int Form1_Load(object sender, EventArgs e)

        {
            if(input==S);
            draw.g.Square(); 
        }   

        public int Form1_Load(object sender, EventArgs e)

        {
            if(input==M);
            draw.g.matchstickfigure(); 
        }   
