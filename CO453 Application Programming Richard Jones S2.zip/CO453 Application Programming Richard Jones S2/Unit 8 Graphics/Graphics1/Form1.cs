using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Graphics1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int x = 50;
            int y = 20;

            Graphics g = e.Graphics;                // create a new graphics object g
            Font myFont = new Font("Times New Roman", 30);    // create a font myFont
            for (int i = 1; i <= 7; i++) g.Clear(BackColor);
            {
                System.Threading.Thread.Sleep(1000);
                g.DrawString("Robert is texting a Window", myFont, Brushes.Blue, x, y);
                y = y + 40;
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
