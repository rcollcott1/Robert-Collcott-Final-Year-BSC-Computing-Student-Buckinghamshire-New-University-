namespace TestKeys
{
    partial class Form1
    {
        string input;
        string input2;
        
        
        
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        protected override bool ProcessCmdKey(ref Message msg,Keys keyData)

        {

            string input;
            input = keyData.ToString();     // collect user input
            if (input=="KeyDown")

            {
                MessageBox.Show("You pressed the down key");
                return true;
            }

            string input2;
            input = keyData.ToString();     // collect user input
            if (input == "KeyUp")
            {
                MessageBox.Show("You pressed the down key");
                return true;
            }



        }




        



        }


        
    }


