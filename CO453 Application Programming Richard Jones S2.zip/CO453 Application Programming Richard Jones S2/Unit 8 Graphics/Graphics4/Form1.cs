using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Graphics4
{
    // author Robert Collcott
    // date 7th April 2015 
    // Drawing lines

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.LightGreen;

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;             			// get a graphics object
            Pen myPen = new Pen(Color.Red, 10);  	        // create a new red pen

            // draw a line using the pen from (x1,y1) to (x2, y2)
            g.DrawLine(myPen, 200, 300, 50, 50);
            g.DrawLine(myPen, 200, 300, 50, 50);

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            x += move; y += ymove;
            Referesh();


        }


    }
}