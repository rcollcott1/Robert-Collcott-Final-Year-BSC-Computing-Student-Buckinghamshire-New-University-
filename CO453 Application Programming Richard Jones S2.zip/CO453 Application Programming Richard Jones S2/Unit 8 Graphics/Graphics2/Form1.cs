using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Graphics2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            double DrawRectangle;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int x = 80,  y = 10;     // position of rectangle
            int w = 300, h = 200;    // width and height of reactangle
            Graphics g = e.Graphics; // get a graphics object

            Pen myPen = new Pen(Color.Blue, 10);  // define a blue pen size 10
 
            g.DrawRectangle(myPen, x, y, w, h);         // draw a rectangle using pen
            g.FillRectangle(Brushes.Red, x, y, w, h);   // fill the rectangle with a red brush colour
            g.FillEllipse(Brushes.Yellow, x, y, w, h);

            for (int i = 0; i < 6; i++)        // Loop that will draw six rentangles 
	{
        DrawRectangle();
	}
    }



        }
    }
