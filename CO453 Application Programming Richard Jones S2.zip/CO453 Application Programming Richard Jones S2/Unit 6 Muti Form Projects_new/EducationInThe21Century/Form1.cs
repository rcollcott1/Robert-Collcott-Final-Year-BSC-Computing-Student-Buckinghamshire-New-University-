﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Qasim Rabbani
//ID:21302405


namespace EducationInThe21Century
{
    public partial class frmDataEntry : Form
    {
        int sno;
        double total, lunch, dinner;
        int totalDelegates = 0;
        const int SchoolCount = 5;
        string[] schoolName;
        int[] numTeachersFromSchool;
        double[] schoolTotal;

        public frmDataEntry()
        {
            schoolName = new string[SchoolCount];
            numTeachersFromSchool = new int[SchoolCount];
            schoolTotal = new double[SchoolCount];
            for (int i = 0; i < SchoolCount; i++)
            {
                numTeachersFromSchool[i] = 0;
                schoolTotal[i] = 0;
            }
            schoolName[0] = "Bucks High School";
            schoolName[1] = "Ealing High";
            schoolName[2] = "Dormers Wells High School";
            schoolName[3] = "Lady Margeret School";
            schoolName[4] = "Wycombe High School";
            InitializeComponent();
        }
        
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private int getSchoolNo(string pSchoolName)
        {


            if (pSchoolName.Equals("Bucks High School")) return 0;
            if (pSchoolName.Equals("Ealing High")) return 1;
            if (pSchoolName.Equals("Dormers Wells High School")) return 2;
            if (pSchoolName.Equals("Lady Margeret School")) return 3;
            if (pSchoolName.Equals("Wycombe High School")) return 4;
            return -1;
        }

        private void btnBill_Click(object sender, EventArgs e)
        {
            int j1;
            frmBillForm newBill = new frmBillForm();
            newBill.Show();
            newBill.lblName.Text = txtName.Text;
            newBill.lblSchool.Text = cbxSchool.Text;
            total = lunch + dinner;
            total = total + 50;
            newBill.lblTotalBill.Text = total.ToString();
            j1 = newBill.acceptFlag;

            if (j1 == 1)
            {
                sno = getSchoolNo(cbxSchool.Text);
                if (sno != -1)
                {
                    totalDelegates++;
                    numTeachersFromSchool[sno]++;
                    schoolTotal[sno] = total;
                }
                else
                {
                    MessageBox.Show("School not found!!!!: " + cbxSchool.Text);
                }
            }

        }

        private void btnTotal_Click(object sender, EventArgs e)
        {
            frmTotal newTotal = new frmTotal();
            newTotal.lblTeachNum.Text = numTeachersFromSchool[sno].ToString();
            newTotal.lblSchoolNum1.Text = numTeachersFromSchool[0].ToString();
            newTotal.lblSchoolNum2.Text = numTeachersFromSchool[1].ToString();
            newTotal.lblSchoolNum3.Text = numTeachersFromSchool[2].ToString();
            newTotal.lblSchoolNum4.Text = numTeachersFromSchool[3].ToString();
            newTotal.lblSchoolNum5.Text = numTeachersFromSchool[4].ToString();
            newTotal.lblAllBills1.Text = schoolTotal[0].ToString();
            newTotal.lblAllBills2.Text = schoolTotal[1].ToString();
            newTotal.lblAllBills3.Text = schoolTotal[2].ToString();
            newTotal.lblAllBills4.Text = schoolTotal[3].ToString();
            newTotal.lblAllBills5.Text = schoolTotal[4].ToString();
            newTotal.Show();
            
            
        }

        private void cbxLunch_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxLunch.Checked)
            {
                lunch = lunch += 10;
            }
            else
            {
                lunch = lunch -= 10;
            }
        }

        private void cbxDinner_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxDinner.Checked)
            {
                dinner = dinner += 15;
            }
            else
            {
                dinner = dinner -= 15;
            }
        }

        private void cbxSchool_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbxSchool.Text)
            {
                case "Bucks High School": break;
                case "Ealing Highl": break;
                case "Dormers Wells High School": break;
                case "Lady Margeret School": break;
                case "Wycombe High School": break;
            }

            
        }

        private void frmDataEntry_Load(object sender, EventArgs e)
        {

        }
    }
}
