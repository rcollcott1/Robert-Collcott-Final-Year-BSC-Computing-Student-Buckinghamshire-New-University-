﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EducationInThe21Century
{
    public partial class frmBillForm : Form
    {
        int teacher = 0;
        public int acceptFlag;
        public frmBillForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void btnAccept_Click(object sender, EventArgs e)
        {
            //frmTotal newTotal = new frmTotal();
            
            DialogResult response;
            response = MessageBox.Show("Are you happy with your choices ? ",
                "Accept Bill", MessageBoxButtons.YesNo);
            if (response == DialogResult.Yes)
            {
               // teacher++;
                acceptFlag = 1;
                //newTotal.lblTeachNum.Text = teacher.ToString();      
            }
            else acceptFlag = 0;
            
        }

        public int billAccepted() 
        {
         return acceptFlag;
 //           frmBillForm = acceptFlag
        }
    }
}
