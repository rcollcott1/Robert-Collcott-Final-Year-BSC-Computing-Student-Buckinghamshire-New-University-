﻿namespace EducationInThe21Century
{
    partial class frmDataEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnBill = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.cbxSchool = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.cbxLunch = new System.Windows.Forms.CheckBox();
            this.cbxDinner = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnQuit
            // 
            this.btnQuit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuit.Location = new System.Drawing.Point(336, 306);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(116, 44);
            this.btnQuit.TabIndex = 0;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.Location = new System.Drawing.Point(167, 306);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(98, 44);
            this.btnTotal.TabIndex = 1;
            this.btnTotal.Text = "Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // btnBill
            // 
            this.btnBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBill.Location = new System.Drawing.Point(12, 306);
            this.btnBill.Name = "btnBill";
            this.btnBill.Size = new System.Drawing.Size(95, 44);
            this.btnBill.TabIndex = 2;
            this.btnBill.Text = "View Bill";
            this.btnBill.UseVisualStyleBackColor = true;
            this.btnBill.Click += new System.EventHandler(this.btnBill_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "Data Entry Form";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(14, 75);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(66, 24);
            this.lbl1.TabIndex = 4;
            this.lbl1.Text = "Name:";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(14, 125);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(74, 24);
            this.lbl2.TabIndex = 5;
            this.lbl2.Text = "School:";
            // 
            // cbxSchool
            // 
            this.cbxSchool.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxSchool.FormattingEnabled = true;
            this.cbxSchool.Items.AddRange(new object[] {
            "Bredon School 2002 Ltd",
            "HCC ",
            "Halford School",
            "Lady Margeret School",
            "Wycombe High School"});
            this.cbxSchool.Location = new System.Drawing.Point(106, 122);
            this.cbxSchool.Name = "cbxSchool";
            this.cbxSchool.Size = new System.Drawing.Size(137, 32);
            this.cbxSchool.TabIndex = 6;
            this.cbxSchool.Text = "Click here";
            this.cbxSchool.SelectedIndexChanged += new System.EventHandler(this.cbxSchool_SelectedIndexChanged);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(106, 75);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(137, 29);
            this.txtName.TabIndex = 7;
            // 
            // cbxLunch
            // 
            this.cbxLunch.AutoSize = true;
            this.cbxLunch.Location = new System.Drawing.Point(106, 177);
            this.cbxLunch.Name = "cbxLunch";
            this.cbxLunch.Size = new System.Drawing.Size(56, 17);
            this.cbxLunch.TabIndex = 8;
            this.cbxLunch.Text = "Lunch";
            this.cbxLunch.UseVisualStyleBackColor = true;
            this.cbxLunch.CheckedChanged += new System.EventHandler(this.cbxLunch_CheckedChanged);
            // 
            // cbxDinner
            // 
            this.cbxDinner.AutoSize = true;
            this.cbxDinner.Location = new System.Drawing.Point(106, 214);
            this.cbxDinner.Name = "cbxDinner";
            this.cbxDinner.Size = new System.Drawing.Size(57, 17);
            this.cbxDinner.TabIndex = 9;
            this.cbxDinner.Text = "Dinner";
            this.cbxDinner.UseVisualStyleBackColor = true;
            this.cbxDinner.CheckedChanged += new System.EventHandler(this.cbxDinner_CheckedChanged);
            // 
            // frmDataEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(464, 362);
            this.Controls.Add(this.cbxDinner);
            this.Controls.Add(this.cbxLunch);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.cbxSchool);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBill);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.btnQuit);
            this.Name = "frmDataEntry";
            this.Text = "frmDataEntry";
            this.Load += new System.EventHandler(this.frmDataEntry_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnBill;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.ComboBox cbxSchool;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.CheckBox cbxLunch;
        private System.Windows.Forms.CheckBox cbxDinner;
    }
}

