using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// Robert Collcott
// ID 21302939
// Computing 
// 2014-15 Academic Year
// 28th May 2015 


namespace Monkey
{
    public partial class Form1 : Form
    {                                               // This is the distance varirable
        double distance;                
        double Hit=1;

        int x, y;                                   // These are the cordnatinte varirables 
        Random rand = new Random();                               

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            x = rand.Next(this.Width - 200);                                                                  
            y = rand.Next(this.Height - 200);                                       
            pbxPicture.Left = x;                      // set the picture to the left as x which is 200
            pbxPicture.Top = y;                       // set the picture to the left as y which is 200
            Refresh();                                      // This will re draw the image in a new postion 
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;                                  // start the timer control
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;                                 // stop the timer control 
        }

        private void button1_Click(object sender, EventArgs e)      // exit the program completly  
        {
            Application.Exit();
        }

        private void pbxPicture_Click(object sender, EventArgs e)           // This is the picture box that has the target image in  
        {
            lblResult1.Text = Hit.ToString();                           // this is the hit score
            Hit = Hit + 0;  
            Hit++;                                                      // increment the hits by one each time e.g. 1 to 2 
        }

        private void pbxPicture_MouseDown(object sender, MouseEventArgs e)
        {
        }

        private void pbxPicture_MouseClick(object sender, MouseEventArgs e)         // This is the picture box for the target image
        {
            distance = Math.Sqrt(Math.Pow((e.X - 50), 2) + Math.Pow((e.Y - 50), 2));
            MessageBox.Show("The mouse X position is " + e.X + "\n The mouse Y position is " + e.Y + "\nThe distance is" + dist);

            if(distance<=20)
            {
                lblB.Text = "Bullseye!";                // This is what will output on the screen if the distance is less than 20 meters from hitting the target  
            }
          
        }
    }
}


