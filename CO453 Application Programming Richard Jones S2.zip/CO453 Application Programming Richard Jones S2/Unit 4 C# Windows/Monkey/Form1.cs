using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Monkey
{
    public partial class Form1 : Form
    {
        int x, y;
        int distance;
        Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            x = rand.Next(this.Width - 100);  // pick a random x   
            y = rand.Next(this.Height - 100); // pick a random y
            pbxPicture.Left = x;              // set picture to these values
            pbxPicture.Top = y;
            distance = Math.Sqrt(Math.Pow(e.x - 50) + Math.Pow(e.y - 50));
            Refresh();                        // redraw in new position
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Application.Run();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pbxPicture_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }


    }
}
