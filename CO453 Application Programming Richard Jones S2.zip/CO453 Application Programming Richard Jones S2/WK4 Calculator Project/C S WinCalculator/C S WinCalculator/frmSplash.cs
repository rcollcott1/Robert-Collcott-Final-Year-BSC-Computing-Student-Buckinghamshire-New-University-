﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_S_WinCalculator
{
    public partial class frmsplash : Form
    {
        public frmsplash()
        {
            InitializeComponent();
        }

        private void frmsplash_Load(object sender, EventArgs e)
        {
            frmSplash SScreen = new frmSplash();   

            SScreen.Show();			   
     
            System.Threading.Thread.Sleep(2000); 

            SScreen.Close();			       

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
