﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4._7_Hit_the_Target

    // Robert Collcott
    // ID 21302939
    // Computing 
    // 19th March 2015



{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnHello_Click(object sender, EventArgs e)             // This is the hello button
        {
            int count;
            
           for (count = 0; count < 11; count++) ;                           // This is the for loop

           DialogResult response;
            response MessageBox.Show "Do you like programming?";   "Check"


                if (response 



           MessageBox.Show("Hello World", "Greetings to all");

            MessageBox.Show("Hello Sean");
            MessageBox.Show("Hello Adam");
            MessageBox.Show("Welcome to the world of application programming");

        }
    }
}
