
/**
 * Write a description of class ManageEvent here.
 * 
 * @author: Robert Collcott Elaine Foon and Temi Dare
 * @version 2.4
 */
public class ManageEvent
{
    //
    public String newName;
    public int newMax;
    public int newPrice;
    
    // The price of a ticket from this machine.
    public int price;
    //The max number of tickets that allows user to buy per event. 
    public int max;
    //
    public String eventName;

    /**
     * Constructor for objects of class ManageEvent
     */
    public ManageEvent(String eventName, int price, int max)
    {
       this.eventName= eventName;
       this. price= price; 
       this. max= max; 
    }
    
    /**
     * set event's name. 
     */
    public void setName(String newName)
    {
        eventName= newName; 
    }

    /**
     * Input the max number of tickets that allow to buy for current event.
     */
    public void setMax(int newMax)
    {
        max= newMax; 
    }
    
    /**
     * Input the price for ticket. 
     */
    public void setPrice(int newPrice)
    {
        price = newPrice; 
    }
    
     /**
     * Return The price of a ticket.
     */
    public int getPrice()
    {
        return price;
    }
    
    /**
     * Display the max number of tickets that allow to buy for current event. 
     */
    public int getMax()
    {
        return max;
    }
    
    
    /**
     * print event's details
     */
    public void printEventDetails()
    {
        System.out.println();
        System.out.println();
        System.out.println("--------------------");
        System.out.println("Event's name: " + eventName);
        System.out.println("Price: £" + price);
        System.out.println("Max per purchase: " + max);
        System.out.println("--------------------");
    }
}