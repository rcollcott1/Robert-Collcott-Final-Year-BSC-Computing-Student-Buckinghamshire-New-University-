
/**
 * Description: A class to store all the methods for buy ticket. 
 * 
 * @author: Robert Collcott, Elaine Foon and Temi Dare
 * @version 2.4
 */
public class Purchase
{
    // Call variable from ManageEvent class. 
    private ManageEvent manage;
    // call method/ variable from promotion class. 
    private Promotion promo;
    // The total of ticket of buying. 
    public int noTicket=0; 
    // The amount of money entered by a customer so far.
    public int balance=0;
    // The total amount of money collected by this machine.
    public int total=0;
    // amount of money
    public int amount=0;
    
    //declare variable
    public String eventName; 
    public int price; 
    public int max; 
    public int rowNo; 
    public int seatNumber; 
    public String blockS; 
    
    /**
     * Constructor for objects of class Purchase
     */    
    public Purchase()
    {
        manage= new ManageEvent(eventName, price, max);
        promo= new Promotion();
    }
    
    /**
     * select seat that wish to buy. 
     */
    public void selectSeat(String block, int row, int sNumber)
    {
        blockS= block; 
        rowNo= row; 
        seatNumber= sNumber; 
        
        System.out.println("Block: "+ blockS);
        System.out.println("Row: "+ rowNo);
        System.out.println("Seat number: "+ seatNumber);
    }
    
    /**
     * Return the number of ticket that want to buy. 
     */
    public void buyTicket(int noTicket)
    {
        for(int i=0; i==noTicket; i++)
        {
            selectSeat(blockS,rowNo,seatNumber);
        }
        
        if(noTicket>=manage.max)
        {
        total= noTicket * manage.price;
        total= total- promo.discount;
        
        System.out.println("");
        System.out.println("-----------------------------");
        System.out.println("You have buy "+ noTicket +" ticket(s).");
        System.out.println("Discount: £"+ promo.discount);
        System.out.println("Total cost: "+ total);
        System.out.println("-----------------------------");
        System.out.println("");
        }
        else
        {
            System.out.println("");
            System.out.println("-----------------------");
            System.out.println(" Should be no more than "+ manage.max);
            System.out.println("-----------------------");
            System.out.println("");
        }
    }
    
     /**
     * Return The amount of money already inserted for the next ticket.
     */
    public int getBalance()
    {
        return balance;
    }
    
    /**
     * Receive an amount of money from a customer.
     * Check that the amount is sensible.
     */
    public void insertMoney(int amount)
    {
        if(amount > 0) {
            balance = balance + amount;
        }
        else {
            System.out.println("Use a positive amount rather than: " +
                               amount);
        }
    }
    
     /**
     * Print a ticket if enough money has been inserted, and 
     * reduce the current balance by the ticket price. Print
     * an error message if more money is required.
     */
    public void printTicket()
    {
        if(balance >= manage.price) {
            // Simulate the printing of a ticket.
            System.out.println("");
            System.out.println("");
            System.out.println("You have buy "+ noTicket +" ticket(s).");
            System.out.println("##################");
            System.out.println("Discount: £"+ promo.discount);
            System.out.println("##################");
            System.out.println("Cost in total: " + manage.price + " cents.");
            System.out.println("##################");
            System.out.println("");

            // Update the total collected with the price.
            total = total + manage.price;
            total= total- promo.discount;
            // Reduce the balance by the prince.
            balance = balance - manage.price;
        }
        else {
            System.out.println("You must insert at least: " +
                               (total - balance) + " more cents.");
                    
        }
    }
}
