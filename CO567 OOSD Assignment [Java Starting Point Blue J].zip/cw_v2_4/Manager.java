import java.util.ArrayList;

/**
 * Description: A class for the venue manager. 
 * This class allows venue manager to manage the event's details. 
 * There are methods in this class are calling from the other class. 
 * 
 * @author: Robert Collcott, Elaine Foon and Temi Dare
 * @version 2.4
 *
 */

public class Manager
{
    // declare the costructor that will need to be use later. 
    private Purchase buyIt;
    private CancelPurchase cancelP;
    private ManageEvent manage;
    private Promotion promo;
    //array list 
    private ArrayList<ManageEvent> data; 
    
    // Store variable. 
    private int checkTheBalance;
    private int BuyTic=0;
    private int Payment=0;
    private int RefundIt=0;
    private int Max=0;
    private int Price=0;
    private String Name;
    private int totalDiscount;
    private int price; 
    private int max; 
    private String eventName;
    private int disc;
    
    
    // method from Manager class
    /**
     * This is the own (default) class of this. 
     * In here will create constructors, to make it able to call methods from other classes. 
     */
    public Manager()
    { 
        buyIt= new Purchase();
        cancelP= new CancelPurchase();
        manage= new ManageEvent(eventName, price, max);
        promo= new Promotion();
        
        data= new ArrayList<ManageEvent>();
    }
    
    
    //
    /**
     * 
     */
    public void setDiscount(int sDis)
    {
     promo.setPromo(sDis);
     disc= disc+ sDis;
    }
    
    
    // methods from Purchase class
    /**
     * this is the method of purchase ticket. 
     */
    public void buy(int pBuy)
    {
        buyIt.buyTicket(pBuy);
        BuyTic= pBuy;
    }
    
    /**
     * method of pay for the ticket(s). 
     */
    public void pay(int pPay)
    {
        buyIt.insertMoney(pPay);
        Payment=pPay;
    }
    
    /**
     * check the balance of how much have been pay. 
     */
    public int checkBalance()
    {
        checkTheBalance= buyIt.balance;
        return checkTheBalance;
    }
    
    
    // from CancelPurchase class
    /**
     * method for process the refund. 
     */
    public void refund(int cRefund)
    {
        cancelP.cancel(cRefund);
        RefundIt=cRefund;
    }
    
    
    
    // from ManageEvent class
    /**
     * set event's name
     */
    public void editName(String eName)
    {
        manage.setName(eName);
        Name=eName;
        data.add(new ManageEvent(Name, Price, Max));
    }
    
    /**
     * set max number of ticket that allow to buy each time. 
     */
    public void editMax(int eMax)
    {
        manage.setMax(eMax);
        Max= eMax;
        data.add(new ManageEvent(Name, Price, Max));
    }
    
    /**
     * set price for the event. 
     */
    public void editPrice(int ePrice)
    {
        manage.setPrice(ePrice);
        Price= ePrice;
        data.add(new ManageEvent(Name, Price, Max));
    }
    
    
    
    // Print methods from all classes
    /**
     * print details about refund
     */
    public void printRefund()
    {
        cancelP.print();
    }
    
    /**
     * print ticket/purchase details
     */
    public void printTicket()
    {
        buyIt.printTicket();
    }
    
    /**
     * print details about the event
     */
    public void printEvent()
    {
        manage.printEventDetails();
    }
}