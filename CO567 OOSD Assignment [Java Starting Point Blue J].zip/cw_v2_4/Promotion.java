
/**
 * Write a description of class Promotion here.
 * 
 * @author: Robert Collcott, Elaine Foon and Temi Dare
 * @version 2.4
 */
public class Promotion
{
    // declare the  variable
    public int discount; 

    /**
     * Constructor for objects of class Promotion
     */
    public Promotion()
    {
        discount= 0; 
    }
    
    /**
     * method of promotion for saturday (evening) shows
     */
    public void setPromo(int disOne)
    {
     discount= discount+ disOne;   
    }

}
