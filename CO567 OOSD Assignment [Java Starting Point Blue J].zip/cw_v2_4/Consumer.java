
/**
 * Write a description of class Consumer here.
 * 
 * @author: Robert Collcott, Elaine Foon and Temi Dare
 * @version 2.4
 */
public class Consumer
{
   private Purchase buyIt; 
   public int BuyTic=0;
   public int Payment=0;
   public int checkTheBalance;
   
    /**
     * Constructor for objects of class Consumer
     */
    public Consumer()
    {
        buyIt= new Purchase();
       
    }
    
    // from Purchase class
    /**
     * this is the method of purchase ticket. 
     */
    public void buy(int pBuy)
    {
        buyIt.buyTicket(pBuy);
        BuyTic= pBuy;
    }
    
    /**
     * method of pay for the ticket(s). 
     */
    public void pay(int pPay)
    {
        buyIt.insertMoney(pPay);
        Payment=pPay;
        
    }
    
    /**
     * check the balance of how much have been pay. 
     */
    public int checkBalance()
    {
        checkTheBalance= buyIt.balance;
        return checkTheBalance;
        
    }
    
    
}
