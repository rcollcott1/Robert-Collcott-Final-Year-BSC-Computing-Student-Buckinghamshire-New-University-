<!-- Display the student modules script  --> 
<html>
<head>
</head>
<body>
<style>									<!------- style tag implements a CSS background  11th May 2016 ------>	

body 
{
    background-color: lightblue;
}

</style>

<?php // start of table of modules assigned reference script

    	  session_start();
		  
	  // Connect to the database and inculde the database dbconnect inculde file 
          include("dbconnect.inc");

	  // Build SQL statment that selects a student's modules
	  $sql = "select * from studentmodules sm, module m where m.modulecode = sm.modulecode and sm.studentid = '" . $_SESSION[id] ."';";

	  $result = mysql_query($sql,$conn);

	  echo "<table border='4'>";
	  echo "<tr><th colspan='5' align='center'>Modules</th></tr>";
          echo "<tr><th>Code</th><th>Type</th><th>Level</th></tr>";
		  
	  // Display the modules within the html table
	  
	  while($row = mysql_fetch_array($result)) {
    	    echo "<tr><td> $row[modulecode] </td><td> $row[name] </td>";
 	    echo "<td> $row[level] </td><td></tr>";
          }
 	  echo "</table>";
?>
	<br/><br/>
			<a href="assignmodule.php"><button>Assign New Module</button></a>									<!------- A button link looks more professional on a system 11th May 2016 ------>				
	<br/><br/>
		<a href="Home.html"><button>Return to home screen</button></a>											<!------- A button link looks more professional on a system 11th May 2016 ------>		
	
</body>
</html>