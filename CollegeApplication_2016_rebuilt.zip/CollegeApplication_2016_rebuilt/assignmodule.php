<?php session_start();
// If a module has been selected
if ($_POST[selmodule]){ 
?>
  <html>
  <head>
  </head>
  <body>
  <style type="text/css">			<!------- style tag implements a CSS background  11th May 2016 ------>			

body {
    background-color: lightblue;				// light blue background
}
</style>

<?php
     // Connect to the database
     include("dbconnect.inc");
     // Build sql statment to assign module to student
     $sql = "insert into studentmodules values ('" .  $_SESSION['id'] . "','" . $_POST[selmodule] . "');";
     $result = mysql_query($sql,$conn);
     echo "<h2>The module $_POST[selmodule] has been assigned to you</h2>";
     echo "<a href='modules.php'>Return to modules page</a><br/>";
?>
  </body>
  </html>
<?php
}
else  // If a module has not been selected
{
  echo "<html>";
  echo "<head>";
  echo "</head>";
  echo "<body>";

  // Connect to the database
  include("dbconnect.inc");
  // Build sql statment that selects all the modules
  $sql = "select * from module";
  $result = mysql_query($sql,$conn);

  echo "<form name='frmassignmodule' action='$PHP_SELF' method='post' >";					// build a assign modules form 
  echo "Select a module to assign<br/>";													// display text 
  echo "<select name='selmodule' >";
																		// Display the module name sin a drop down selection box
  while($row = mysql_fetch_array($result)) {
	echo "<option value='$row[modulecode]'>$row[name]</option>";		// print out the module code and name 
  }
  echO "</select><br/>";
  echo "<input type='submit' name='confirm' value='Save' />";			// assign the module to the current student				
  echo "</form>";
  echo "<br/><br/>";
  echo "<a href='modules.php'>Modules page</a><br/>";					// provide a link to the modules page to see what modules have been assinged 
  echo "</body>";
  echo "</html>";
}
?>



