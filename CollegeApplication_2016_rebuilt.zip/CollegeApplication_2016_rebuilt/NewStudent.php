session_start();
    include("dbconnect.inc");


// If the form has been submitted
   <html>
   <head>
   </head>
     <style>			<!------- style tag implements a CSS background  11th May 2016 ------>			

body {
    background-color: lightblue;				// light blue background
}

<?php
}

if ($_POST[submit]){
	
    // Build an sql statment to update the students details
	
    $sql = $sql ."update student set firstname ='" . $_POST[txtfirstname] . "',";
    $sql = $sql . "lastname ='" . $_POST[txtlastname]  . "',";
    $sql = $sql . "house ='" . $_POST[txthouse]  . "',";
    $sql = $sql . "town ='" . $_POST[txttown]  . "',";
    $sql = $sql . "county ='" . $_POST[txtcounty]  . "',";
    $sql = $sql . "country ='" . $_POST[txtcountry]  . "',";
    $sql = $sql . "postcode ='" . $_POST[txtpostcode]  . "' ";
    $sql = $sql . "where studentid = '" . $_SESSION[id] . "';";
	
    $result = mysql_query($sql,$conn);
	
else {
   // Build an sql statment to return the student record whoes id
   // matches that of the session variable.
   $sql = "select * from student where studentid='". $_SESSION[id] . "';";

   $result = mysql_query($sql,$conn);

   $row = mysql_fetch_array($result);

?>	
	


</style>
     <h2>Your details</h2>
     <form name="frmdetails" action="<?php echo $PHP_SELF ?>" method="post">
	 <br>
        First Name :
	<input name="txtfirstname" type="text" value="<?php echo $row[firstname]; ?>" />
        <br/>
        Surname :
		 <br>
        <input name="txtlastname" type="text"  value="<?php echo $row[lastname]; ?>" />
	<br/>
        Number and Street :
		 <br>
	<input name="txthouse" type="text"  value="<?php echo $row[house]; ?>" />
        <br/>
        Town :
		 <br>
        <input name="txttown" type="text"  value="<?php echo $row[town]; ?>" />
	<br/>
	
	Postcode :
		<br>
      <input name="txtpcode" type="text"  value="<?php echo $row[postcode]; ?>" />
        <br/>
        <input type="submit" value="Save" name="submit"/>
	
	
        County :
		 <br>
	<input name="txtcounty" type="text"  value="<?php echo $row[county]; ?>" />
        <br/>
         Country :
		  <br>
	<input name="txtcountry" type="text"  value="<?php echo $row[country]; ?>" />
        <br/>

		
		<!-------------- This is the new inculcation of the delete button--------->
		
		<button type="Delete" value="Delete">Delete</button>



    <html>
    <head></head>
    <body>
	<style type="text/css">			<!------- style tag implements a CSS background  11th May 2016 ------>			

body {
    background-color: lightblue;				// light blue background
}
</style>
      <h2>Your details have been updated</h2>
      <a href="authenticate.php">Menu Page</a>
    </body>
    </html>

      </form>
   </body>
   </html>
<?php
}
?>