<?php 

    //User details can be amended through this script

    session_start();
    include("dbconnect.inc");


// If the form has been submitted

if ($_POST[submit]){
	
    // Build sql statment to update the student details
	
    $sql = "update student set firstname ='" . $_POST[txtfirstname] . "',";						// grab the first name posted value
    $sql = $sql . "lastname ='" . $_POST[txtlastname]  . "',";									// grab the last name posted value
    $sql = $sql . "house ='" . $_POST[txthouse]  . "',";											// grab the house posted value
    $sql = $sql . "town ='" . $_POST[txttown]  . "',";											// grab the town posted value
    $sql = $sql . "county ='" . $_POST[txtcounty]  . "',";												// grab the county posted value
    $sql = $sql . "country ='" . $_POST[txtcountry]  . "',";									// grab the country posted value
    $sql = $sql . "postcode ='" . $_POST[txtpostcode]  . "' ";											// grab the post code posted value
    $sql = $sql . "where studentid = '" . $_SESSION[id] . "';";									// match the ID up with the correct session 
		
    $result = mysql_query($sql,$conn);
	
?>
    <html>
    <head></head>
<style type="text/css">			<!------- style tag implements a CSS background  11th May 2016 ------>			

body
{
  background:#58FAF4; 
}
</style>
      <h2>Your details have been updated</h2>
      <a href="authenticate.php">Menu Page</a>
    </body>
    </html>
<?php
}
else {
   // Build an sql statment to return the student record whoes id
   // matches that of the session variable.
   $sql = "select * from student where studentid='". $_SESSION[id] . "';";

   $result = mysql_query($sql,$conn);

   $row = mysql_fetch_array($result);

?>
   <html>
   <head>
   </head>
   <body>
   <style>			<!------- style tag implements a CSS background  11th May 2016 ------>			

body {
    background-color: lightblue;				// light blue background
}
</style>
     <h2>Please enter details of new students </h2>
     <form name="frmdetails" action="<?php echo $PHP_SELF ?>" method="post">							<!------- start a form to enter student details ------>					
	 
	 <br>
	 
	 <!------- Get user input of everything from first name to post code ------>	
	 	 
        First Name :																							
	<input name="txtfirstname" type="text" value="<?php echo $row[firstname]; ?>" />
        <br/>
        Surname :
		 <br>
        <input name="txtlastname" type="text"  value="<?php echo $row[lastname]; ?>" />
	<br/>
        Number and Street :
		 <br>
	<input name="txthouse" type="text"  value="<?php echo $row[house]; ?>" />
        <br/>
        Town :
		 <br>
        <input name="txttown" type="text"  value="<?php echo $row[town]; ?>" />
	<br/>
        County :
		 <br>
	<input name="txtcounty" type="text"  value="<?php echo $row[county]; ?>" />
        <br/>
         Country :
		  <br>
	<input name="txtcountry" type="text"  value="<?php echo $row[country]; ?>" />
        <br/>
        Postcode :
		 <br>
        <input name="txtpostcode" type="text"  value="<?php echo $row[postcode]; ?>" />
        <br/>
		
	<!-------------- This is the new inculcation of the delete button    10th May 2016     --------->
		
		Checkbox 
		<input type="checkbox" type="text" value="<?php echo $row[Checkbox]; ?>" />
		
		
		<input type="submit" value="Save" name="submit"/>

		
		<!-------------- This is the new inculcation of the delete button    8th May 2016     --------->
		
		<button type="Delete" value="Delete">Delete</button>
      </form>
   </body>
   </html>
<?php
}
?>