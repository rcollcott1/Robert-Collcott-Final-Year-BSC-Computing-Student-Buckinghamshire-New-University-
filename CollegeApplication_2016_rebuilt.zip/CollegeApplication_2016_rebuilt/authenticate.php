<?php

	//  Validates a students ID and password 

        session_start();
        include("dbfunctions.inc");
		
	// If the student has already been authenticated the $_SESSION['id'] variable
	// will been assigned their student id.

	if ($_SESSION['id'] == '' or validatelogin($_POST[txtid],$_POST[txtpwd]) == true){
?>
	  <html>
	  <head>
	  </head>
	  <body>
	  <style type="text/css">			<!------- style tag implements a CSS background  11th May 2016 ------>			

body {
    background-color: lightblue;				// light blue background
}
</style>
		<h2>You have successfully logged into the College Application 2016 system </h2>
		
		<a href="details.php"><button>Your personal details</button></a>									<!------- button link looks more professional on a system 11th May 2016 ------>				

		<a href="modules.php"><button>Enrolled Modules</button></a>											<!------- button link looks more professional on a system 11th May 2016 ------>			

		
	  </body>
	  </html>
	  
<?php 				// else php script 
	}
	else{
?>
	  <html>
	  <head>
	  </head>
	  <body>
	  <style>			<!------- style tag implements a CSS background  11th May 2016 ------>			

body 
{
    background-color: lightblue;				// light blue background
}
</style>

<br>
	      <a href="Home.html">College Application 2016 Home Page</a>
		  
</br>
	  </body>
	  </html>
<?php
	}
?>