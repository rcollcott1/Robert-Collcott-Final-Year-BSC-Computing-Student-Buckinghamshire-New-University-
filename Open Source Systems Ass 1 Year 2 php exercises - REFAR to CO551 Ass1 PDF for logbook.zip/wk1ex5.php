<html>
<body>
<?php
$myfavouritemodule['CO453 Application Programming'];


	$myfavouritemodule = 'CO453 Application Programming';
	echo $myfavouritemodule;
?>
</body>
</html>
 