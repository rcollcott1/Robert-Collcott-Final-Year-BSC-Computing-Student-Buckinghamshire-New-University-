<?php 
	include("myfunctions.inc");				// include the file named myfunctions.inc
	html_header("My second function demo");
	echo "<br/><br/>My salary is �1500 and I'm taxed at 50%<br/><br/>";				// print out the message saying what the salary is 
																					// and how much the tax amount is
	echo "I pay � " . calculatetax(1500,50) . " tax";								// print out message saying the tax amount
	html_footer();										// display footer	
?>
