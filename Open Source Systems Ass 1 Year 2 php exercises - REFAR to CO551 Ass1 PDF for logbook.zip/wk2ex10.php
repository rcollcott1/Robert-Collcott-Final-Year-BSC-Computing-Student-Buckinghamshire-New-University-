<html>
<head>
<title> Marks Script </title>
</head>
<body>
<?php
  $index ["value"] = 90;
  $mymarks["year 1"] = 55;
  $mymarks["year 2"] = 65;
  $mymarks["year 3"] = 75;

  while(list($index,$value) = each($mymarks));
  {
    echo  <br> "for  $index  my grade was  $value " <br/> ;
  }
  echo <br> "My best year was Year 3 when I averaged ". $mymarks[�year 3"] </br> ;
?>
</body>
</html>