<?php		// Start of script 

	if($_POST['txtage']<21)							// If the age inputted is less than 21 echo out a message saying the person is under 21
	
	{
		echo 'You are under 21 years old <br/>'
	}
	
	else ($_POST['txtage']>21)	
	
	{
	echo 'You are 21 years old or over <br/>;'		// if the age inputted is higher than 21 display a message saying you are 21 years old already or over
	}
	
?>