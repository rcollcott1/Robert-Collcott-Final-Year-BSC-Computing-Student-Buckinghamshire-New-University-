<?php			// start of php script

	$hourlyrate	= '5.75';			// hourlyrate is 5.75 

	$hoursperweek = '40';			// hours working per week is 40 

	$gross = $hourlyrate * $hoursperweek;		// to work out the gross value overall we * [times] the two together
	
	echo $gross;				// print out a message stating the gross earnings 

	
	// end of php script
	
?>