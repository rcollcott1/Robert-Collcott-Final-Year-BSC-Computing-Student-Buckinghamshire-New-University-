<?php
      $URL = "http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URL'];					// delcare a URL variable so it picks whatever the web server is 
?>
<html>			<!------ Start of html part 1 of script ------>

<body>
     <h2>My PHP Web Page Translation Script</h2>		<!------ HTML part of script page title ------>	
          
		  <?php				// Start of php part of script
		  
              echo("The URL from SERVER_NAME and REQUEST_URL is ... </br>".$URL."</br></br>")				// print out the current URL at the time wherever the user e.g. http://intweb.bucks.ac.uk
              ?>
			  
</body>
</html>			  


<html>		<!------ Start of html part 2 of script ------>
<body>

     <strong> Choose Your Language: </strong>
     <form action="https://translate.google.co.uk/?hl=en&tab=wT">
        <select name="langpair">							<!------ select list to choose options ------>
               <option value="en|de">German</option>		<!------ option 1 is German ------>
               <option value="en|es">Spanish</option>		<!------ option 2 is Spanish  ------>
               <option value="en|fr">French</option>		<!------ option 3 is French ------>
               <option value="en|it">Italian</option>		<!------ option 4 is Italian ------>
               <option value="en|pt">Portuguese</option>	<!------ option 1 is Portuguese ------>
        </select>
</body>
</html>		
		
<html>	<!------ Start of html part 3 of script ------>
<body>
		<input type=<"submit"> <value="Go!"/>

    
     </form>

</body>
</html>