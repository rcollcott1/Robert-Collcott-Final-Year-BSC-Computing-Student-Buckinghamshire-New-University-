<?php 

if($_POST["Small"]==15.75)
	
	{
		echo "You bought a small size widget <br/>"
	}
	
	if($_POST["Medium"]==16.75)
	
	{
		echo "You bought a medium size widget <br/>"
	}
	
	if($_POST["Large"]==17.75)
	
	{
		echo "You bought a large size widget <br/>"
	}
	
	if($_POST["Extra large"]==18.75)
	
	{
		echo "You bought a extra large size widget <br/>"
	}
	
?>