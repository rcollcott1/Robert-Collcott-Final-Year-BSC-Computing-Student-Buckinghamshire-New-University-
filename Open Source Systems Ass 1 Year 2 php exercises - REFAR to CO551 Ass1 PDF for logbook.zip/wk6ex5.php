<?php 

	include("myfunctions.inc"); // include the file named myfunctions.inc
	html_header("My first function demo");			// have a header named my first function demo 
	html_h1("These functions are going to save me lots of time"); 	// print out this message 
	html_h2("If I can't get this right I<br/>really<br/>really<br/>really<br/> should'nt be teaching!");	// print out this message 		
	html_footer();
?>
