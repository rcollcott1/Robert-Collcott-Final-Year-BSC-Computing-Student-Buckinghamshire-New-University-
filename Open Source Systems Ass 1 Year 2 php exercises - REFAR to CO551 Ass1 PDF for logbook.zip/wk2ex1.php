<?php			// start of php script		


		$hourlyrate	= 5.75;			// delcare hourlyrate variable and set it the value of 5.75
		$hoursperweek = 40;			// delcare hoursperweek variable and set it the value of 40
		$gross = $hourlyrate * $hoursperweek;		// times the hourlyrate and hoursperweek variables together to find out what the gross wage is

// end of php script
		
?>	



	<html>						<!------ Enter HTML Language !------>
	<head>Gross Wage</head>		<!------ This is the page title !------>
<body>						<!------ Form HTML body !------>

	<p> My Gross wage for the week <?php echo '($gross);'?> </p>		<!------ re enter php to print out the person's gross wage for the week !------>			
	
</body>			<!------ Close HTML body !------>
	</html>		<!------ Close HTML Language !------>
