<html>  <!-------- Start of HTML ------> 
<body>	<!-------- Start of HTML Body -----> 

<?php echo 			// print out the server name and protocol 

	$_SERVER	
	[$_�SERVER_NAME�S_�SERVER_PROTOCOL�]; 

	// end php script
	
?> 

</html> 	<!-------- End of HTML  -----> 
</body>		<<!-------- End of HTML Body -----> 