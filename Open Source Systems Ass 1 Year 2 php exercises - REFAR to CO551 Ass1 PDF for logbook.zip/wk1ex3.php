<html>		<!-------- Start HTML !------>
<body>		<!-------- Open the HTML body  !------>

<?php		// start a php script

	echo 'Blimmy it worked !';			// print out the following message
	
	// end the php script
	
?>

</body>		<!-------- Close the HTML body  !------>
</html>		<!-------- Close HTML  !------>
