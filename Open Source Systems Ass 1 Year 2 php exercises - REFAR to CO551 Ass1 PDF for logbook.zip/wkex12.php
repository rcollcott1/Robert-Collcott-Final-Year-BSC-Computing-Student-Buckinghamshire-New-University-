<?php
  $topmodules[0] = Open Source Systems;
  $topmodules[1] = Programming 1;
  $topmodules[2] = Programming 2;
  $topmodules[3] = Web Application Development;
  $topmodules[4] = Software Engineering;
  
  for($count=0$count < 5$count++)
  {
  echo <tr><td>$count</td><td>$topmodules[$count]</td></tr>;
  }	
  ?>
<html>
<head>
<title> Data in a table </title>
</head>
<body>
<table>
<table border=1> <align=center>
<tr><th>Index</th><th>Subject</th></tr> 
</table>
</body>
</html>



