<?php		// start of php script

	include("myfunctions.inc"); 				// include all the functions in the file entitled my functions.inc 
	html_header("My second function demo");		// Script page title 
	echo "<br/><br/>Salary = �2000<br/>Tax threshold =�1000<br/>Tax rate = 40%<br/><br/>";	// print out the salary the person earns
	echo "I pay � " . calcTaxDefaultThreshold(2000, 40, 1000) . " tax";		// print out the tax that the person pays
	html_footer(); 
?>
