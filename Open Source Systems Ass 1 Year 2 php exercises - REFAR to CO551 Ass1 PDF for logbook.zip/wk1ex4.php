<html>		<!-------- Start HTML !------>
<body>		<!-------- Open the HTML body  !------>

<?php				// start a php script

	echo gmdate('M d Y');				// calandar print out in month date and year format M is month D is date and Y is year
	
	// end the php script
	
?>

</body>		<!-------- Close the HTML body  !------>
</html>		<!-------- Close HTML  !------>
