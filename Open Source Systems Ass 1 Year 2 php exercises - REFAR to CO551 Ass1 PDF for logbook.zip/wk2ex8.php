<html>
<head> Behave Script </head>
<title> Behave Script </title>
<body>

<?php
  $topModules[0] = "User Experience [UX]";
  $topModules[1] = "Application Programming";
  $topModules[2] = "Programming Concepts";
  $topModules[3] = "OOSD";
  $topModules[4] = "Software Engineering";

  for($count = 0,$count < 5;$count++);
  {
    echo "$count module is $topModules[$count] <br/>";
  }	
?>
</body>
</html>