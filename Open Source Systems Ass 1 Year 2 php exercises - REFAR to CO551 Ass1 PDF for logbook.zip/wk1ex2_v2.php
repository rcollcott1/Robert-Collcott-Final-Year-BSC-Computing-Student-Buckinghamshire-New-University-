<html>
<body>

<?php echo 

$_SERVER

	echo '$_�SERVER_NAME�S_�SERVER_PROTOCOL'; 

?> 

</html>
</body>