<?php					// Speed camera advise script 

    $points = 12;

  
 // Output the appropriate message depending on the points awarded.
 
 if ($points >= 12) 				// more than 12 points print out a message saying public transport is the best option
{
   echo "Public transport is your best option.<br/>";
}
else ($points >= 9)
{
   echo "If you get caught say your grandmother was driving.<br/>";					// points less than 9 means print out the message saying the grandmother was driving 
}
else ($points <= 7)
{
   echo "There is no need to worry about the speed limit.<br/>";					// points less than 7 print out a message saying there is no need to worry about the speed limt 
}
?> 