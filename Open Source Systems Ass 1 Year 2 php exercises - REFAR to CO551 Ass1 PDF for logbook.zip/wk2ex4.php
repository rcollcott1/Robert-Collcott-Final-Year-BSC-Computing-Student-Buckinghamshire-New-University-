<?php				// Speed camera advise script 

  $points = 13;				// set the points variable to 13  
  
  // Output appropriate message depending on points awarded.
  
 if ( $points >= 12)
{
   echo "Public transport is your best option. <br/>";					// if you get more than 12 points output public transport message 
}
elseif ($points >= 9)
{
   echo "If you get caught say your grandmother was driving. <br/>";	// if you do not get more than 9 points print out the granny mother driving message
}
else 
{
   echo "There is no need to worry about the speed limit.<br/>";		// If you do not get any points just print out a message saying no need to worry about the limit 
}
?> 
