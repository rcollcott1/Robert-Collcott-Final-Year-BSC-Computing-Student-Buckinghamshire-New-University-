<html>
<body>
<?php
	$firstname = �Richard�;
	$lastname = �Mather�;
	$name = $firstname . $lastname;
	echo $name;
?>
</body>
</html>
