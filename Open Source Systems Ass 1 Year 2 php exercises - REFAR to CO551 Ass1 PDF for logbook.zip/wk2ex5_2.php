<?php		// start of php script 
if (strpos($_SERVER["HTTP_USER_AGENT"], "MSIE") != false) 				// Declare MS IE as the variable 			
{
   echo "You are using Internet Explorer <br>"						// If Internet expoler is being used print out you are using internet explorer 
}
else
{
   echo "Why are you not using Internet Explorer ?";				// if browser chosen is not Internet explorer print out a message "Why are you not using Internet Explorer   
}
?> 
