<html>
<head>
</head>
<title> Age Script </title>
<body>

<?php 
$myage = "23 <br>";
$oldage = "21 <br>";

	<?php echo($myage);
	$myage = 23;
	<?php echo($oldage <br/>�);
	$oldage = 21;
?>	
</body>
</html>