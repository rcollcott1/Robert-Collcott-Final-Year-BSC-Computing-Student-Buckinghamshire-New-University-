<html>
  <head>
  </head>
  <title>Select colour page
  </title>
    <body>
      <form action="confirmation.php"  method="post">
	Select the colour for the widgets 

   	<select name="selectcolour">
   	  <option>White</option>
	  <option>Red</option>
	  <option>Yellow</option>
	  <option>Green</option>
	  <option>Blue</option>
        </select>
		
        <br/>
		<br/>	
<?php echo 
	$_POST[selqty] ?> how many widgets are you ordering
	   	<select name="selectqty">
		<form action="size.php"  method="post">
   	  <option>1</option>
	  <option>2</option>
	  <option>3</option>
	  <option>4</option>
	  <option>5</option>
	
	<br>
	<br>
	</br>
	  <input type="submit" value="Buy"/>
      </form>
   </body>
</html>	
