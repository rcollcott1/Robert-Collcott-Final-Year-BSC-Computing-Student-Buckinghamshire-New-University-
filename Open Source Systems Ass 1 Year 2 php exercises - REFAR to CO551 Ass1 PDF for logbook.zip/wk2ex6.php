<html>
<head>
<title> Marks Script </title>
</head>
<body>
<?php					// Marks Script
  $marks[0] = 65;
  $marks[1] = 55;
  $marks[2] = 76;
  $marks[3] = 82;
  $marks[4] = 48;
  $marks[5] = 78;
  
  echo Index 0 = $marks[0] </br>;
  echo Index 1 = $marks[1] </br>;
  echo Index 2 = $marks[2] </br>;
  echo Index 3 = $marks[3] </br>;
  echo Index 4 = $marks[4] </br>;
  echo Index 5 = $marks[5] </br>;
  
?>
</body>
</html>

