<?php
	include("myfunctions.inc");					// include all the functions for the script in a file named my functions.inc
	html_header("My second function demo"); 	// define a header
	echo "<br/><br/>My salary is �1000 and I'm taxed at 40%<br/><br/>"; 	// print out the salary and tax rate of the employee
	echo "I pay � " . calcTaxDefault(1000) . " tax";		// print out how much tax the person pays
	html_footer();
?>
